﻿namespace Proyecto
{
    partial class Form_Desplazamientos
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.btnRefrescar = new System.Windows.Forms.Button();
            this.btnEditar = new System.Windows.Forms.Button();
            this.txtPos22 = new System.Windows.Forms.NumericUpDown();
            this.label18 = new System.Windows.Forms.Label();
            this.txtPos21 = new System.Windows.Forms.NumericUpDown();
            this.label19 = new System.Windows.Forms.Label();
            this.txtPos20 = new System.Windows.Forms.NumericUpDown();
            this.label20 = new System.Windows.Forms.Label();
            this.txtPos19 = new System.Windows.Forms.NumericUpDown();
            this.label21 = new System.Windows.Forms.Label();
            this.txtPos18 = new System.Windows.Forms.NumericUpDown();
            this.label22 = new System.Windows.Forms.Label();
            this.txtPos17 = new System.Windows.Forms.NumericUpDown();
            this.label23 = new System.Windows.Forms.Label();
            this.txtPos16 = new System.Windows.Forms.NumericUpDown();
            this.label9 = new System.Windows.Forms.Label();
            this.txtPos15 = new System.Windows.Forms.NumericUpDown();
            this.label10 = new System.Windows.Forms.Label();
            this.txtPos14 = new System.Windows.Forms.NumericUpDown();
            this.label11 = new System.Windows.Forms.Label();
            this.txtPos13 = new System.Windows.Forms.NumericUpDown();
            this.label13 = new System.Windows.Forms.Label();
            this.txtPos12 = new System.Windows.Forms.NumericUpDown();
            this.label14 = new System.Windows.Forms.Label();
            this.txtPos11 = new System.Windows.Forms.NumericUpDown();
            this.label15 = new System.Windows.Forms.Label();
            this.txtPos10 = new System.Windows.Forms.NumericUpDown();
            this.label16 = new System.Windows.Forms.Label();
            this.txtPos09 = new System.Windows.Forms.NumericUpDown();
            this.label17 = new System.Windows.Forms.Label();
            this.txtPos08 = new System.Windows.Forms.NumericUpDown();
            this.label5 = new System.Windows.Forms.Label();
            this.txtPos07 = new System.Windows.Forms.NumericUpDown();
            this.label6 = new System.Windows.Forms.Label();
            this.txtPos06 = new System.Windows.Forms.NumericUpDown();
            this.label7 = new System.Windows.Forms.Label();
            this.txtPos05 = new System.Windows.Forms.NumericUpDown();
            this.label8 = new System.Windows.Forms.Label();
            this.txtPos04 = new System.Windows.Forms.NumericUpDown();
            this.label3 = new System.Windows.Forms.Label();
            this.txtPos03 = new System.Windows.Forms.NumericUpDown();
            this.label4 = new System.Windows.Forms.Label();
            this.txtPos02 = new System.Windows.Forms.NumericUpDown();
            this.label2 = new System.Windows.Forms.Label();
            this.txtPos01 = new System.Windows.Forms.NumericUpDown();
            this.btnGUARDAR = new System.Windows.Forms.Button();
            this.lblSegundos = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.txtPosOrigen = new System.Windows.Forms.TextBox();
            this.lblPosOrigen = new System.Windows.Forms.Label();
            this.txtPos00 = new System.Windows.Forms.NumericUpDown();
            this.label12 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtPos22)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtPos21)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtPos20)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtPos19)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtPos18)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtPos17)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtPos16)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtPos15)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtPos14)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtPos13)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtPos12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtPos11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtPos10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtPos09)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtPos08)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtPos07)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtPos06)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtPos05)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtPos04)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtPos03)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtPos02)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtPos01)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtPos00)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.AllowUserToResizeColumns = false;
            this.dataGridView1.AllowUserToResizeRows = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(80, 103);
            this.dataGridView1.MultiSelect = false;
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.Size = new System.Drawing.Size(1542, 537);
            this.dataGridView1.TabIndex = 0;
            this.dataGridView1.RowEnter += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_RowEnter);
            // 
            // btnRefrescar
            // 
            this.btnRefrescar.Location = new System.Drawing.Point(80, 69);
            this.btnRefrescar.Name = "btnRefrescar";
            this.btnRefrescar.Size = new System.Drawing.Size(174, 29);
            this.btnRefrescar.TabIndex = 81;
            this.btnRefrescar.Text = "REFRESCAR";
            this.btnRefrescar.UseVisualStyleBackColor = true;
            this.btnRefrescar.Click += new System.EventHandler(this.btnRefrescar_Click);
            // 
            // btnEditar
            // 
            this.btnEditar.Location = new System.Drawing.Point(92, 710);
            this.btnEditar.Name = "btnEditar";
            this.btnEditar.Size = new System.Drawing.Size(100, 30);
            this.btnEditar.TabIndex = 221;
            this.btnEditar.Text = "EDITAR";
            this.btnEditar.UseVisualStyleBackColor = true;
            this.btnEditar.Click += new System.EventHandler(this.btnEditar_Click);
            // 
            // txtPos22
            // 
            this.txtPos22.Location = new System.Drawing.Point(1556, 666);
            this.txtPos22.Maximum = new decimal(new int[] {
            500,
            0,
            0,
            0});
            this.txtPos22.Name = "txtPos22";
            this.txtPos22.Size = new System.Drawing.Size(56, 20);
            this.txtPos22.TabIndex = 220;
            this.txtPos22.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(1558, 649);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(37, 13);
            this.label18.TabIndex = 219;
            this.label18.Text = "Pos22";
            // 
            // txtPos21
            // 
            this.txtPos21.Location = new System.Drawing.Point(1495, 666);
            this.txtPos21.Maximum = new decimal(new int[] {
            500,
            0,
            0,
            0});
            this.txtPos21.Name = "txtPos21";
            this.txtPos21.Size = new System.Drawing.Size(56, 20);
            this.txtPos21.TabIndex = 218;
            this.txtPos21.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(1497, 649);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(37, 13);
            this.label19.TabIndex = 217;
            this.label19.Text = "Pos21";
            // 
            // txtPos20
            // 
            this.txtPos20.Location = new System.Drawing.Point(1433, 666);
            this.txtPos20.Maximum = new decimal(new int[] {
            500,
            0,
            0,
            0});
            this.txtPos20.Name = "txtPos20";
            this.txtPos20.Size = new System.Drawing.Size(56, 20);
            this.txtPos20.TabIndex = 216;
            this.txtPos20.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(1435, 649);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(37, 13);
            this.label20.TabIndex = 215;
            this.label20.Text = "Pos20";
            // 
            // txtPos19
            // 
            this.txtPos19.Location = new System.Drawing.Point(1372, 666);
            this.txtPos19.Maximum = new decimal(new int[] {
            500,
            0,
            0,
            0});
            this.txtPos19.Name = "txtPos19";
            this.txtPos19.Size = new System.Drawing.Size(56, 20);
            this.txtPos19.TabIndex = 214;
            this.txtPos19.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(1374, 649);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(37, 13);
            this.label21.TabIndex = 213;
            this.label21.Text = "Pos19";
            // 
            // txtPos18
            // 
            this.txtPos18.Location = new System.Drawing.Point(1310, 666);
            this.txtPos18.Maximum = new decimal(new int[] {
            500,
            0,
            0,
            0});
            this.txtPos18.Name = "txtPos18";
            this.txtPos18.Size = new System.Drawing.Size(56, 20);
            this.txtPos18.TabIndex = 212;
            this.txtPos18.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(1312, 649);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(37, 13);
            this.label22.TabIndex = 211;
            this.label22.Text = "Pos18";
            // 
            // txtPos17
            // 
            this.txtPos17.Location = new System.Drawing.Point(1249, 666);
            this.txtPos17.Maximum = new decimal(new int[] {
            500,
            0,
            0,
            0});
            this.txtPos17.Name = "txtPos17";
            this.txtPos17.Size = new System.Drawing.Size(56, 20);
            this.txtPos17.TabIndex = 210;
            this.txtPos17.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(1251, 649);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(37, 13);
            this.label23.TabIndex = 209;
            this.label23.Text = "Pos17";
            // 
            // txtPos16
            // 
            this.txtPos16.Location = new System.Drawing.Point(1187, 666);
            this.txtPos16.Maximum = new decimal(new int[] {
            500,
            0,
            0,
            0});
            this.txtPos16.Name = "txtPos16";
            this.txtPos16.Size = new System.Drawing.Size(56, 20);
            this.txtPos16.TabIndex = 208;
            this.txtPos16.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(1189, 649);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(37, 13);
            this.label9.TabIndex = 207;
            this.label9.Text = "Pos16";
            // 
            // txtPos15
            // 
            this.txtPos15.Location = new System.Drawing.Point(1126, 666);
            this.txtPos15.Maximum = new decimal(new int[] {
            500,
            0,
            0,
            0});
            this.txtPos15.Name = "txtPos15";
            this.txtPos15.Size = new System.Drawing.Size(56, 20);
            this.txtPos15.TabIndex = 206;
            this.txtPos15.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(1128, 649);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(37, 13);
            this.label10.TabIndex = 205;
            this.label10.Text = "Pos15";
            // 
            // txtPos14
            // 
            this.txtPos14.Location = new System.Drawing.Point(1064, 666);
            this.txtPos14.Maximum = new decimal(new int[] {
            500,
            0,
            0,
            0});
            this.txtPos14.Name = "txtPos14";
            this.txtPos14.Size = new System.Drawing.Size(56, 20);
            this.txtPos14.TabIndex = 204;
            this.txtPos14.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(1066, 649);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(37, 13);
            this.label11.TabIndex = 203;
            this.label11.Text = "Pos14";
            // 
            // txtPos13
            // 
            this.txtPos13.Location = new System.Drawing.Point(1003, 666);
            this.txtPos13.Maximum = new decimal(new int[] {
            500,
            0,
            0,
            0});
            this.txtPos13.Name = "txtPos13";
            this.txtPos13.Size = new System.Drawing.Size(56, 20);
            this.txtPos13.TabIndex = 202;
            this.txtPos13.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(1005, 649);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(37, 13);
            this.label13.TabIndex = 201;
            this.label13.Text = "Pos13";
            // 
            // txtPos12
            // 
            this.txtPos12.Location = new System.Drawing.Point(941, 666);
            this.txtPos12.Maximum = new decimal(new int[] {
            500,
            0,
            0,
            0});
            this.txtPos12.Name = "txtPos12";
            this.txtPos12.Size = new System.Drawing.Size(56, 20);
            this.txtPos12.TabIndex = 200;
            this.txtPos12.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(943, 649);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(37, 13);
            this.label14.TabIndex = 199;
            this.label14.Text = "Pos12";
            // 
            // txtPos11
            // 
            this.txtPos11.Location = new System.Drawing.Point(880, 666);
            this.txtPos11.Maximum = new decimal(new int[] {
            500,
            0,
            0,
            0});
            this.txtPos11.Name = "txtPos11";
            this.txtPos11.Size = new System.Drawing.Size(56, 20);
            this.txtPos11.TabIndex = 198;
            this.txtPos11.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(882, 649);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(37, 13);
            this.label15.TabIndex = 197;
            this.label15.Text = "Pos11";
            // 
            // txtPos10
            // 
            this.txtPos10.Location = new System.Drawing.Point(818, 666);
            this.txtPos10.Maximum = new decimal(new int[] {
            500,
            0,
            0,
            0});
            this.txtPos10.Name = "txtPos10";
            this.txtPos10.Size = new System.Drawing.Size(56, 20);
            this.txtPos10.TabIndex = 196;
            this.txtPos10.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(820, 649);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(37, 13);
            this.label16.TabIndex = 195;
            this.label16.Text = "Pos10";
            // 
            // txtPos09
            // 
            this.txtPos09.Location = new System.Drawing.Point(757, 666);
            this.txtPos09.Maximum = new decimal(new int[] {
            500,
            0,
            0,
            0});
            this.txtPos09.Name = "txtPos09";
            this.txtPos09.Size = new System.Drawing.Size(56, 20);
            this.txtPos09.TabIndex = 194;
            this.txtPos09.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(759, 649);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(37, 13);
            this.label17.TabIndex = 193;
            this.label17.Text = "Pos09";
            // 
            // txtPos08
            // 
            this.txtPos08.Location = new System.Drawing.Point(696, 665);
            this.txtPos08.Maximum = new decimal(new int[] {
            500,
            0,
            0,
            0});
            this.txtPos08.Name = "txtPos08";
            this.txtPos08.Size = new System.Drawing.Size(56, 20);
            this.txtPos08.TabIndex = 192;
            this.txtPos08.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(698, 648);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(37, 13);
            this.label5.TabIndex = 191;
            this.label5.Text = "Pos08";
            // 
            // txtPos07
            // 
            this.txtPos07.Location = new System.Drawing.Point(635, 665);
            this.txtPos07.Maximum = new decimal(new int[] {
            500,
            0,
            0,
            0});
            this.txtPos07.Name = "txtPos07";
            this.txtPos07.Size = new System.Drawing.Size(56, 20);
            this.txtPos07.TabIndex = 190;
            this.txtPos07.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(637, 648);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(37, 13);
            this.label6.TabIndex = 189;
            this.label6.Text = "Pos07";
            // 
            // txtPos06
            // 
            this.txtPos06.Location = new System.Drawing.Point(573, 665);
            this.txtPos06.Maximum = new decimal(new int[] {
            500,
            0,
            0,
            0});
            this.txtPos06.Name = "txtPos06";
            this.txtPos06.Size = new System.Drawing.Size(56, 20);
            this.txtPos06.TabIndex = 188;
            this.txtPos06.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(575, 648);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(37, 13);
            this.label7.TabIndex = 187;
            this.label7.Text = "Pos06";
            // 
            // txtPos05
            // 
            this.txtPos05.Location = new System.Drawing.Point(512, 665);
            this.txtPos05.Maximum = new decimal(new int[] {
            500,
            0,
            0,
            0});
            this.txtPos05.Name = "txtPos05";
            this.txtPos05.Size = new System.Drawing.Size(56, 20);
            this.txtPos05.TabIndex = 186;
            this.txtPos05.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(514, 648);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(37, 13);
            this.label8.TabIndex = 185;
            this.label8.Text = "Pos05";
            // 
            // txtPos04
            // 
            this.txtPos04.Location = new System.Drawing.Point(450, 665);
            this.txtPos04.Maximum = new decimal(new int[] {
            500,
            0,
            0,
            0});
            this.txtPos04.Name = "txtPos04";
            this.txtPos04.Size = new System.Drawing.Size(56, 20);
            this.txtPos04.TabIndex = 184;
            this.txtPos04.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(452, 648);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(37, 13);
            this.label3.TabIndex = 183;
            this.label3.Text = "Pos04";
            // 
            // txtPos03
            // 
            this.txtPos03.Location = new System.Drawing.Point(388, 665);
            this.txtPos03.Maximum = new decimal(new int[] {
            500,
            0,
            0,
            0});
            this.txtPos03.Name = "txtPos03";
            this.txtPos03.Size = new System.Drawing.Size(56, 20);
            this.txtPos03.TabIndex = 182;
            this.txtPos03.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(390, 648);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(37, 13);
            this.label4.TabIndex = 181;
            this.label4.Text = "Pos03";
            // 
            // txtPos02
            // 
            this.txtPos02.Location = new System.Drawing.Point(326, 665);
            this.txtPos02.Maximum = new decimal(new int[] {
            500,
            0,
            0,
            0});
            this.txtPos02.Name = "txtPos02";
            this.txtPos02.Size = new System.Drawing.Size(56, 20);
            this.txtPos02.TabIndex = 180;
            this.txtPos02.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(328, 648);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(37, 13);
            this.label2.TabIndex = 179;
            this.label2.Text = "Pos02";
            // 
            // txtPos01
            // 
            this.txtPos01.Location = new System.Drawing.Point(265, 665);
            this.txtPos01.Maximum = new decimal(new int[] {
            500,
            0,
            0,
            0});
            this.txtPos01.Name = "txtPos01";
            this.txtPos01.Size = new System.Drawing.Size(56, 20);
            this.txtPos01.TabIndex = 178;
            this.txtPos01.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // btnGUARDAR
            // 
            this.btnGUARDAR.Location = new System.Drawing.Point(202, 710);
            this.btnGUARDAR.Name = "btnGUARDAR";
            this.btnGUARDAR.Size = new System.Drawing.Size(100, 30);
            this.btnGUARDAR.TabIndex = 177;
            this.btnGUARDAR.Text = "GUARDAR";
            this.btnGUARDAR.UseVisualStyleBackColor = true;
            this.btnGUARDAR.Click += new System.EventHandler(this.btnGUARDAR_Click);
            // 
            // lblSegundos
            // 
            this.lblSegundos.AutoSize = true;
            this.lblSegundos.Location = new System.Drawing.Point(1618, 668);
            this.lblSegundos.Name = "lblSegundos";
            this.lblSegundos.Size = new System.Drawing.Size(55, 13);
            this.lblSegundos.TabIndex = 176;
            this.lblSegundos.Text = "Segundos";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(267, 648);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(37, 13);
            this.label1.TabIndex = 175;
            this.label1.Text = "Pos01";
            // 
            // txtPosOrigen
            // 
            this.txtPosOrigen.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPosOrigen.Location = new System.Drawing.Point(84, 665);
            this.txtPosOrigen.Name = "txtPosOrigen";
            this.txtPosOrigen.ReadOnly = true;
            this.txtPosOrigen.Size = new System.Drawing.Size(100, 22);
            this.txtPosOrigen.TabIndex = 174;
            this.txtPosOrigen.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lblPosOrigen
            // 
            this.lblPosOrigen.AutoSize = true;
            this.lblPosOrigen.Location = new System.Drawing.Point(116, 648);
            this.lblPosOrigen.Name = "lblPosOrigen";
            this.lblPosOrigen.Size = new System.Drawing.Size(38, 13);
            this.lblPosOrigen.TabIndex = 173;
            this.lblPosOrigen.Text = "Origen";
            // 
            // txtPos00
            // 
            this.txtPos00.Location = new System.Drawing.Point(203, 666);
            this.txtPos00.Maximum = new decimal(new int[] {
            500,
            0,
            0,
            0});
            this.txtPos00.Name = "txtPos00";
            this.txtPos00.Size = new System.Drawing.Size(56, 20);
            this.txtPos00.TabIndex = 223;
            this.txtPos00.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(205, 649);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(37, 13);
            this.label12.TabIndex = 222;
            this.label12.Text = "Pos00";
            // 
            // Form_Desplazamientos
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1884, 961);
            this.ControlBox = false;
            this.Controls.Add(this.txtPos00);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.btnEditar);
            this.Controls.Add(this.txtPos22);
            this.Controls.Add(this.label18);
            this.Controls.Add(this.txtPos21);
            this.Controls.Add(this.label19);
            this.Controls.Add(this.txtPos20);
            this.Controls.Add(this.label20);
            this.Controls.Add(this.txtPos19);
            this.Controls.Add(this.label21);
            this.Controls.Add(this.txtPos18);
            this.Controls.Add(this.label22);
            this.Controls.Add(this.txtPos17);
            this.Controls.Add(this.label23);
            this.Controls.Add(this.txtPos16);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.txtPos15);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.txtPos14);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.txtPos13);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.txtPos12);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.txtPos11);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.txtPos10);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.txtPos09);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.txtPos08);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.txtPos07);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.txtPos06);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.txtPos05);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.txtPos04);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.txtPos03);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.txtPos02);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txtPos01);
            this.Controls.Add(this.btnGUARDAR);
            this.Controls.Add(this.lblSegundos);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtPosOrigen);
            this.Controls.Add(this.lblPosOrigen);
            this.Controls.Add(this.btnRefrescar);
            this.Controls.Add(this.dataGridView1);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Form_Desplazamientos";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "DESPLAZAMIENTOS";
            this.Load += new System.EventHandler(this.Form_Desplazamientos_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtPos22)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtPos21)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtPos20)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtPos19)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtPos18)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtPos17)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtPos16)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtPos15)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtPos14)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtPos13)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtPos12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtPos11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtPos10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtPos09)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtPos08)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtPos07)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtPos06)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtPos05)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtPos04)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtPos03)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtPos02)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtPos01)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtPos00)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button btnRefrescar;
        private System.Windows.Forms.Button btnEditar;
        private System.Windows.Forms.NumericUpDown txtPos22;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.NumericUpDown txtPos21;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.NumericUpDown txtPos20;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.NumericUpDown txtPos19;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.NumericUpDown txtPos18;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.NumericUpDown txtPos17;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.NumericUpDown txtPos16;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.NumericUpDown txtPos15;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.NumericUpDown txtPos14;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.NumericUpDown txtPos13;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.NumericUpDown txtPos12;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.NumericUpDown txtPos11;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.NumericUpDown txtPos10;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.NumericUpDown txtPos09;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.NumericUpDown txtPos08;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.NumericUpDown txtPos07;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.NumericUpDown txtPos06;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.NumericUpDown txtPos05;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.NumericUpDown txtPos04;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.NumericUpDown txtPos03;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.NumericUpDown txtPos02;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.NumericUpDown txtPos01;
        private System.Windows.Forms.Button btnGUARDAR;
        private System.Windows.Forms.Label lblSegundos;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtPosOrigen;
        private System.Windows.Forms.Label lblPosOrigen;
        private System.Windows.Forms.NumericUpDown txtPos00;
        private System.Windows.Forms.Label label12;
    }
}