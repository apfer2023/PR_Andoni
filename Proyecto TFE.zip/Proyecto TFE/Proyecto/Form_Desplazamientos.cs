﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;

namespace Proyecto
{
    public partial class Form_Desplazamientos : Form
    {

        public string EstadoConexion;
        public OleDbConnection cn1;
        public OleDbConnection cn2;
        public string MiSelectGeneral;
        public DataSet dsGeneral;
        public DataTable dtGeneral;
        public DataRow drGeneral;
        public OleDbDataAdapter caGeneral;
        public System.Data.OleDb.OleDbCommand Comando2;

        public int filaselec;
        public string PosicionModificada;
        public bool habilitar;


        public Form_Desplazamientos()
        {
            InitializeComponent();
            habilitar = false;
            PosicionModificada = "";
            txtPos00.Enabled = false;
            txtPos01.Enabled = false;
            txtPos02.Enabled = false;
            txtPos03.Enabled = false;
            txtPos04.Enabled = false;
            txtPos05.Enabled = false;
            txtPos06.Enabled = false;
            txtPos07.Enabled = false;
            txtPos08.Enabled = false;
            txtPos09.Enabled = false;
            txtPos10.Enabled = false;
            txtPos11.Enabled = false;
            txtPos12.Enabled = false;
            txtPos13.Enabled = false;
            txtPos14.Enabled = false;
            txtPos15.Enabled = false;
            txtPos16.Enabled = false;
            txtPos17.Enabled = false;
            txtPos18.Enabled = false;
            txtPos19.Enabled = false;
            txtPos20.Enabled = false;
            txtPos21.Enabled = false;
            txtPos22.Enabled = false;
            btnGUARDAR.Enabled = false;
        }

        public void RellenarGridGeneral()
        {
            int b = 0;
            cn1 = new OleDbConnection(Program.CadenaConexion);

            EstadoConexion = Convert.ToString(cn1.State);
            try
            {
                txtPos00.Enabled = false;
                txtPos01.Enabled = false;
                txtPos02.Enabled = false;
                txtPos03.Enabled = false;
                txtPos04.Enabled = false;
                txtPos05.Enabled = false;
                txtPos06.Enabled = false;
                txtPos07.Enabled = false;
                txtPos08.Enabled = false;
                txtPos09.Enabled = false;
                txtPos10.Enabled = false;
                txtPos11.Enabled = false;
                txtPos12.Enabled = false;
                txtPos13.Enabled = false;
                txtPos14.Enabled = false;
                txtPos15.Enabled = false;
                txtPos16.Enabled = false;
                txtPos17.Enabled = false;
                txtPos18.Enabled = false;
                txtPos19.Enabled = false;
                txtPos20.Enabled = false;
                txtPos21.Enabled = false;
                txtPos22.Enabled = false;

                MiSelectGeneral = "SELECT * FROM TablaDesplazamientos ORDER BY PosicionOrigen ASC";
                dataGridView1.Rows.Clear();
                dsGeneral = new System.Data.DataSet();
                dtGeneral = new System.Data.DataTable();
                caGeneral = new OleDbDataAdapter(MiSelectGeneral, cn1);
                caGeneral.Fill(dsGeneral, "GENERALGRID");
                dataGridView1.AutoGenerateColumns = false;
                dataGridView1.ColumnCount = 24;
                dtGeneral = dsGeneral.Tables[0];

                dataGridView1.Columns[0].Name = "Posición_Origen";
                dataGridView1.Columns[1].Name = "TP00";
                dataGridView1.Columns[2].Name = "TP01";
                dataGridView1.Columns[3].Name = "TP02";
                dataGridView1.Columns[4].Name = "TP03";
                dataGridView1.Columns[5].Name = "TP04";
                dataGridView1.Columns[6].Name = "TP05";
                dataGridView1.Columns[7].Name = "TP06";
                dataGridView1.Columns[8].Name = "TP07";
                dataGridView1.Columns[9].Name = "TP08";
                dataGridView1.Columns[10].Name = "TP09";
                dataGridView1.Columns[11].Name = "TP10";
                dataGridView1.Columns[12].Name = "TP11";
                dataGridView1.Columns[13].Name = "TP12";
                dataGridView1.Columns[14].Name = "TP13";
                dataGridView1.Columns[15].Name = "TP14";
                dataGridView1.Columns[16].Name = "TP15";
                dataGridView1.Columns[17].Name = "TP16";
                dataGridView1.Columns[18].Name = "TP17";
                dataGridView1.Columns[19].Name = "TP18";
                dataGridView1.Columns[20].Name = "TP19";
                dataGridView1.Columns[21].Name = "TP20";
                dataGridView1.Columns[22].Name = "TP21";
                dataGridView1.Columns[23].Name = "TP22";

                dataGridView1.Columns["Posición_Origen"].SortMode = DataGridViewColumnSortMode.NotSortable;
                dataGridView1.Columns["TP00"].SortMode = DataGridViewColumnSortMode.NotSortable;
                dataGridView1.Columns["TP01"].SortMode = DataGridViewColumnSortMode.NotSortable;
                dataGridView1.Columns["TP02"].SortMode = DataGridViewColumnSortMode.NotSortable;
                dataGridView1.Columns["TP03"].SortMode = DataGridViewColumnSortMode.NotSortable;
                dataGridView1.Columns["TP04"].SortMode = DataGridViewColumnSortMode.NotSortable;
                dataGridView1.Columns["TP05"].SortMode = DataGridViewColumnSortMode.NotSortable;
                dataGridView1.Columns["TP06"].SortMode = DataGridViewColumnSortMode.NotSortable;
                dataGridView1.Columns["TP07"].SortMode = DataGridViewColumnSortMode.NotSortable;
                dataGridView1.Columns["TP08"].SortMode = DataGridViewColumnSortMode.NotSortable;
                dataGridView1.Columns["TP09"].SortMode = DataGridViewColumnSortMode.NotSortable;
                dataGridView1.Columns["TP10"].SortMode = DataGridViewColumnSortMode.NotSortable;
                dataGridView1.Columns["TP11"].SortMode = DataGridViewColumnSortMode.NotSortable;
                dataGridView1.Columns["TP12"].SortMode = DataGridViewColumnSortMode.NotSortable;
                dataGridView1.Columns["TP13"].SortMode = DataGridViewColumnSortMode.NotSortable;
                dataGridView1.Columns["TP14"].SortMode = DataGridViewColumnSortMode.NotSortable;
                dataGridView1.Columns["TP15"].SortMode = DataGridViewColumnSortMode.NotSortable;
                dataGridView1.Columns["TP16"].SortMode = DataGridViewColumnSortMode.NotSortable;
                dataGridView1.Columns["TP17"].SortMode = DataGridViewColumnSortMode.NotSortable;
                dataGridView1.Columns["TP18"].SortMode = DataGridViewColumnSortMode.NotSortable;
                dataGridView1.Columns["TP19"].SortMode = DataGridViewColumnSortMode.NotSortable;
                dataGridView1.Columns["TP20"].SortMode = DataGridViewColumnSortMode.NotSortable;
                dataGridView1.Columns["TP21"].SortMode = DataGridViewColumnSortMode.NotSortable;
                dataGridView1.Columns["TP22"].SortMode = DataGridViewColumnSortMode.NotSortable;

                dataGridView1.Columns["Posición_Origen"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
                dataGridView1.Columns["TP00"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
                dataGridView1.Columns["TP01"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
                dataGridView1.Columns["TP02"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
                dataGridView1.Columns["TP03"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
                dataGridView1.Columns["TP04"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
                dataGridView1.Columns["TP05"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
                dataGridView1.Columns["TP06"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
                dataGridView1.Columns["TP07"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
                dataGridView1.Columns["TP08"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
                dataGridView1.Columns["TP09"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
                dataGridView1.Columns["TP10"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
                dataGridView1.Columns["TP11"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
                dataGridView1.Columns["TP12"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
                dataGridView1.Columns["TP13"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
                dataGridView1.Columns["TP14"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
                dataGridView1.Columns["TP15"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
                dataGridView1.Columns["TP16"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
                dataGridView1.Columns["TP17"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
                dataGridView1.Columns["TP18"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
                dataGridView1.Columns["TP19"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
                dataGridView1.Columns["TP20"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
                dataGridView1.Columns["TP21"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
                dataGridView1.Columns["TP22"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

                dataGridView1.Columns["Posición_Origen"].Width = 100;
                dataGridView1.Columns["TP00"].Width = 60;
                dataGridView1.Columns["TP01"].Width = 60;
                dataGridView1.Columns["TP02"].Width = 60;
                dataGridView1.Columns["TP03"].Width = 60;
                dataGridView1.Columns["TP04"].Width = 60;
                dataGridView1.Columns["TP05"].Width = 60;
                dataGridView1.Columns["TP06"].Width = 60;
                dataGridView1.Columns["TP07"].Width = 60;
                dataGridView1.Columns["TP08"].Width = 60;
                dataGridView1.Columns["TP09"].Width = 60;
                dataGridView1.Columns["TP10"].Width = 60;
                dataGridView1.Columns["TP11"].Width = 60;
                dataGridView1.Columns["TP12"].Width = 60;
                dataGridView1.Columns["TP13"].Width = 60;
                dataGridView1.Columns["TP14"].Width = 60;
                dataGridView1.Columns["TP15"].Width = 60;
                dataGridView1.Columns["TP16"].Width = 60;
                dataGridView1.Columns["TP17"].Width = 60;
                dataGridView1.Columns["TP18"].Width = 60;
                dataGridView1.Columns["TP19"].Width = 60;
                dataGridView1.Columns["TP20"].Width = 60;
                dataGridView1.Columns["TP21"].Width = 60;
                dataGridView1.Columns["TP22"].Width = 60;

                if (dtGeneral.Rows.Count > 0)
                {
                    dataGridView1.Rows.Add(dtGeneral.Rows.Count);
                }

                if (dtGeneral.Rows.Count > 0)
                {

                    for (b = 0; b < dtGeneral.Rows.Count; b++)
                    {
                        drGeneral = dtGeneral.Rows[b];

                        if (drGeneral["PosicionOrigen"].ToString().Trim() == PosicionModificada) { dataGridView1.Rows[b].DefaultCellStyle.BackColor = Color.Yellow; }

                        dataGridView1.Rows[b].Cells[0].Style.BackColor = Color.Bisque;
                        dataGridView1.Rows[b].Cells[b + 1].Style.BackColor = Color.Gray;
                        dataGridView1.Rows[b].Cells[0].Value = drGeneral["PosicionOrigen"].ToString().Trim();
                        dataGridView1.Rows[b].Cells[1].Value = drGeneral["TPosicion0"].ToString().Trim();
                        dataGridView1.Rows[b].Cells[2].Value = drGeneral["TPosicion1"].ToString().Trim();
                        dataGridView1.Rows[b].Cells[3].Value = drGeneral["TPosicion2"].ToString().Trim();
                        dataGridView1.Rows[b].Cells[4].Value = drGeneral["TPosicion3"].ToString().Trim();
                        dataGridView1.Rows[b].Cells[5].Value = drGeneral["TPosicion4"].ToString().Trim();
                        dataGridView1.Rows[b].Cells[6].Value = drGeneral["TPosicion5"].ToString().Trim();
                        dataGridView1.Rows[b].Cells[7].Value = drGeneral["TPosicion6"].ToString().Trim();
                        dataGridView1.Rows[b].Cells[8].Value = drGeneral["TPosicion7"].ToString().Trim();
                        dataGridView1.Rows[b].Cells[9].Value = drGeneral["TPosicion8"].ToString().Trim();
                        dataGridView1.Rows[b].Cells[10].Value = drGeneral["TPosicion9"].ToString().Trim();
                        dataGridView1.Rows[b].Cells[11].Value = drGeneral["TPosicion10"].ToString().Trim();
                        dataGridView1.Rows[b].Cells[12].Value = drGeneral["TPosicion11"].ToString().Trim();
                        dataGridView1.Rows[b].Cells[13].Value = drGeneral["TPosicion12"].ToString().Trim();
                        dataGridView1.Rows[b].Cells[14].Value = drGeneral["TPosicion13"].ToString().Trim();
                        dataGridView1.Rows[b].Cells[15].Value = drGeneral["TPosicion14"].ToString().Trim();
                        dataGridView1.Rows[b].Cells[16].Value = drGeneral["TPosicion15"].ToString().Trim();
                        dataGridView1.Rows[b].Cells[17].Value = drGeneral["TPosicion16"].ToString().Trim();
                        dataGridView1.Rows[b].Cells[18].Value = drGeneral["TPosicion17"].ToString().Trim();
                        dataGridView1.Rows[b].Cells[19].Value = drGeneral["TPosicion18"].ToString().Trim();
                        dataGridView1.Rows[b].Cells[20].Value = drGeneral["TPosicion19"].ToString().Trim();
                        dataGridView1.Rows[b].Cells[21].Value = drGeneral["TPosicion20"].ToString().Trim();
                        dataGridView1.Rows[b].Cells[22].Value = drGeneral["TPosicion21"].ToString().Trim();
                        dataGridView1.Rows[b].Cells[23].Value = drGeneral["TPosicion22"].ToString().Trim();

                    }

                }
                else
                {

                }
                habilitar = true;
                cn1.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("ERROR EN CARGAR DATAGRIDVIEW1 TABLA DESPLAZAMIENTOS\n" + ex.Message);
            }
            finally
            {
            }
        }

        private void btnRefrescar_Click(object sender, EventArgs e)
        {
            habilitar = false;
            btnGUARDAR.Enabled = false;
            PosicionModificada = "";
            RellenarGridGeneral();
        }

        private void dataGridView1_RowEnter(object sender, DataGridViewCellEventArgs e)
        {
            if (habilitar == true)
            {
                filaselec = e.RowIndex;
                txtPosOrigen.Text = dataGridView1.Rows[filaselec].Cells[0].Value.ToString();
                txtPos00.Text = dataGridView1.Rows[filaselec].Cells[1].Value.ToString();
                txtPos01.Text = dataGridView1.Rows[filaselec].Cells[2].Value.ToString();
                txtPos02.Text = dataGridView1.Rows[filaselec].Cells[3].Value.ToString();
                txtPos03.Text = dataGridView1.Rows[filaselec].Cells[4].Value.ToString();
                txtPos04.Text = dataGridView1.Rows[filaselec].Cells[5].Value.ToString();
                txtPos05.Text = dataGridView1.Rows[filaselec].Cells[6].Value.ToString();
                txtPos06.Text = dataGridView1.Rows[filaselec].Cells[7].Value.ToString();
                txtPos07.Text = dataGridView1.Rows[filaselec].Cells[8].Value.ToString();
                txtPos08.Text = dataGridView1.Rows[filaselec].Cells[9].Value.ToString();
                txtPos09.Text = dataGridView1.Rows[filaselec].Cells[10].Value.ToString();
                txtPos10.Text = dataGridView1.Rows[filaselec].Cells[11].Value.ToString();
                txtPos11.Text = dataGridView1.Rows[filaselec].Cells[12].Value.ToString();
                txtPos12.Text = dataGridView1.Rows[filaselec].Cells[13].Value.ToString();
                txtPos13.Text = dataGridView1.Rows[filaselec].Cells[14].Value.ToString();
                txtPos14.Text = dataGridView1.Rows[filaselec].Cells[15].Value.ToString();
                txtPos15.Text = dataGridView1.Rows[filaselec].Cells[16].Value.ToString();
                txtPos16.Text = dataGridView1.Rows[filaselec].Cells[17].Value.ToString();
                txtPos17.Text = dataGridView1.Rows[filaselec].Cells[18].Value.ToString();
                txtPos18.Text = dataGridView1.Rows[filaselec].Cells[19].Value.ToString();
                txtPos19.Text = dataGridView1.Rows[filaselec].Cells[20].Value.ToString();
                txtPos20.Text = dataGridView1.Rows[filaselec].Cells[21].Value.ToString();
                txtPos21.Text = dataGridView1.Rows[filaselec].Cells[22].Value.ToString();
                txtPos22.Text = dataGridView1.Rows[filaselec].Cells[23].Value.ToString();

                txtPos00.BackColor = Color.White;
                txtPos01.BackColor = Color.White;
                txtPos02.BackColor = Color.White;
                txtPos03.BackColor = Color.White;
                txtPos04.BackColor = Color.White;
                txtPos05.BackColor = Color.White;
                txtPos06.BackColor = Color.White;
                txtPos07.BackColor = Color.White;
                txtPos08.BackColor = Color.White;
                txtPos09.BackColor = Color.White;
                txtPos10.BackColor = Color.White;
                txtPos11.BackColor = Color.White;
                txtPos12.BackColor = Color.White;
                txtPos13.BackColor = Color.White;
                txtPos14.BackColor = Color.White;
                txtPos15.BackColor = Color.White;
                txtPos16.BackColor = Color.White;
                txtPos17.BackColor = Color.White;
                txtPos18.BackColor = Color.White;
                txtPos19.BackColor = Color.White;
                txtPos20.BackColor = Color.White;
                txtPos21.BackColor = Color.White;
                txtPos22.BackColor = Color.White;

                if (filaselec == 0) { txtPos00.BackColor = Color.Gray; }
                if (filaselec == 1) { txtPos01.BackColor = Color.Gray; }
                if (filaselec == 2) { txtPos02.BackColor = Color.Gray; }
                if (filaselec == 3) { txtPos03.BackColor = Color.Gray; }
                if (filaselec == 4) { txtPos04.BackColor = Color.Gray; }
                if (filaselec == 5) { txtPos05.BackColor = Color.Gray; }
                if (filaselec == 6) { txtPos06.BackColor = Color.Gray; }
                if (filaselec == 7) { txtPos07.BackColor = Color.Gray; }
                if (filaselec == 8) { txtPos08.BackColor = Color.Gray; }
                if (filaselec == 9) { txtPos09.BackColor = Color.Gray; }
                if (filaselec == 10) { txtPos10.BackColor = Color.Gray; }
                if (filaselec == 11) { txtPos11.BackColor = Color.Gray; }
                if (filaselec == 12) { txtPos12.BackColor = Color.Gray; }
                if (filaselec == 13) { txtPos13.BackColor = Color.Gray; }
                if (filaselec == 14) { txtPos14.BackColor = Color.Gray; }
                if (filaselec == 15) { txtPos15.BackColor = Color.Gray; }
                if (filaselec == 16) { txtPos16.BackColor = Color.Gray; }
                if (filaselec == 17) { txtPos17.BackColor = Color.Gray; }
                if (filaselec == 18) { txtPos18.BackColor = Color.Gray; }
                if (filaselec == 19) { txtPos19.BackColor = Color.Gray; }
                if (filaselec == 20) { txtPos20.BackColor = Color.Gray; }
                if (filaselec == 21) { txtPos21.BackColor = Color.Gray; }
                if (filaselec == 22) { txtPos22.BackColor = Color.Gray; }

                txtPos00.Enabled = false;
                txtPos01.Enabled = false;
                txtPos02.Enabled = false;
                txtPos03.Enabled = false;
                txtPos04.Enabled = false;
                txtPos05.Enabled = false;
                txtPos06.Enabled = false;
                txtPos07.Enabled = false;
                txtPos08.Enabled = false;
                txtPos09.Enabled = false;
                txtPos10.Enabled = false;
                txtPos11.Enabled = false;
                txtPos12.Enabled = false;
                txtPos13.Enabled = false;
                txtPos14.Enabled = false;
                txtPos15.Enabled = false;
                txtPos16.Enabled = false;
                txtPos17.Enabled = false;
                txtPos18.Enabled = false;
                txtPos19.Enabled = false;
                txtPos20.Enabled = false;
                txtPos21.Enabled = false;
                txtPos22.Enabled = false;
                btnGUARDAR.Enabled = false;
            }
        }

        private void btnGUARDAR_Click(object sender, EventArgs e)
        {
            string StringUpdate;

            string Posicion_guardada;

            StringUpdate = "UPDATE TablaDesplazamientos SET "
                + "FechaHora = getdate(),"
                + "TPosicion0 = " + txtPos00.Value + ","
                + "TPosicion1 = " + txtPos01.Value + ","
                + "TPosicion2 = " + txtPos02.Value + ","
                + "TPosicion3 = " + txtPos03.Value + ","
                + "TPosicion4 = " + txtPos04.Value + ","
                + "TPosicion5 = " + txtPos05.Value + ","
                + "TPosicion6 = " + txtPos06.Value + ","
                + "TPosicion7 = " + txtPos07.Value + ","
                + "TPosicion8 = " + txtPos08.Value + ","
                + "TPosicion9 = " + txtPos09.Value + ","
                + "TPosicion10 = " + txtPos10.Value + ","
                + "TPosicion11 = " + txtPos11.Value + ","
                + "TPosicion12 = " + txtPos12.Value + ","
                + "TPosicion13 = " + txtPos13.Value + ","
                + "TPosicion14 = " + txtPos14.Value + ","
                + "TPosicion15 = " + txtPos15.Value + ","
                + "TPosicion16 = " + txtPos16.Value + ","
                + "TPosicion17 = " + txtPos17.Value + ","
                + "TPosicion18 = " + txtPos18.Value + ","
                + "TPosicion19 = " + txtPos19.Value + ","
                + "TPosicion20 = " + txtPos20.Value + ","
                + "TPosicion21 = " + txtPos21.Value + ","
                + "TPosicion22 = " + txtPos22.Value + ""
                + " WHERE PosicionOrigen = '" + txtPosOrigen.Text + "'";

            Posicion_guardada = txtPosOrigen.Text.Trim();

            cn2 = new OleDbConnection(Program.CadenaConexion);

            try
            {
                cn2.Open();
                Comando2 = new System.Data.OleDb.OleDbCommand(StringUpdate);
                Comando2.Connection = cn2;
                Comando2.ExecuteNonQuery();
                cn2.Close();

                txtPos00.Enabled = false;
                txtPos01.Enabled = false;
                txtPos02.Enabled = false;
                txtPos03.Enabled = false;
                txtPos04.Enabled = false;
                txtPos05.Enabled = false;
                txtPos06.Enabled = false;
                txtPos07.Enabled = false;
                txtPos08.Enabled = false;
                txtPos09.Enabled = false;
                txtPos10.Enabled = false;
                txtPos11.Enabled = false;
                txtPos12.Enabled = false;
                txtPos13.Enabled = false;
                txtPos14.Enabled = false;
                txtPos15.Enabled = false;
                txtPos16.Enabled = false;
                txtPos17.Enabled = false;
                txtPos18.Enabled = false;
                txtPos19.Enabled = false;
                txtPos20.Enabled = false;
                txtPos21.Enabled = false;
                txtPos22.Enabled = false;

                dataGridView1.Rows.Clear();
                habilitar = false;
                PosicionModificada = Posicion_guardada;
                RellenarGridGeneral();

            }
            catch (Exception ex)
            {
                MessageBox.Show("ERROR SQL AL ACTUALIZAR TABLA DESPLAZAMIENTOS " + ex.Message);
            }
            finally
            {
            }
        }

        private void btnEditar_Click(object sender, EventArgs e)
        {
            if (txtPos01.Enabled == true)
            {
                txtPos00.Enabled = false;
                txtPos01.Enabled = false;
                txtPos02.Enabled = false;
                txtPos03.Enabled = false;
                txtPos04.Enabled = false;
                txtPos05.Enabled = false;
                txtPos06.Enabled = false;
                txtPos07.Enabled = false;
                txtPos08.Enabled = false;
                txtPos09.Enabled = false;
                txtPos10.Enabled = false;
                txtPos11.Enabled = false;
                txtPos12.Enabled = false;
                txtPos13.Enabled = false;
                txtPos14.Enabled = false;
                txtPos15.Enabled = false;
                txtPos16.Enabled = false;
                txtPos17.Enabled = false;
                txtPos18.Enabled = false;
                txtPos19.Enabled = false;
                txtPos20.Enabled = false;
                txtPos21.Enabled = false;
                txtPos22.Enabled = false;
                btnGUARDAR.Enabled = false;
            }

            else
            {
                txtPos00.Enabled = true;
                txtPos01.Enabled = true;
                txtPos02.Enabled = true;
                txtPos03.Enabled = true;
                txtPos04.Enabled = true;
                txtPos05.Enabled = true;
                txtPos06.Enabled = true;
                txtPos07.Enabled = true;
                txtPos08.Enabled = true;
                txtPos09.Enabled = true;
                txtPos10.Enabled = true;
                txtPos11.Enabled = true;
                txtPos12.Enabled = true;
                txtPos13.Enabled = true;
                txtPos14.Enabled = true;
                txtPos15.Enabled = true;
                txtPos16.Enabled = true;
                txtPos17.Enabled = true;
                txtPos18.Enabled = true;
                txtPos19.Enabled = true;
                txtPos20.Enabled = true;
                txtPos21.Enabled = true;
                txtPos22.Enabled = true;
                btnGUARDAR.Enabled = true;
            }
        }

        private void Form_Desplazamientos_Load(object sender, EventArgs e)
        {
            habilitar = false;
            btnGUARDAR.Enabled = false;
            PosicionModificada = "";
            RellenarGridGeneral();
        }
    }
}
