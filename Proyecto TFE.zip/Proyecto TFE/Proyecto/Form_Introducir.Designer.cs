﻿namespace Proyecto
{
    partial class Form_Introducir
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label4 = new System.Windows.Forms.Label();
            this.btnIntroducir = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.pGantt = new System.Windows.Forms.Panel();
            this.lblResta = new System.Windows.Forms.Label();
            this.pnVerticalAzul = new System.Windows.Forms.Panel();
            this.lblRojo = new System.Windows.Forms.Label();
            this.pnVerticalRoja = new System.Windows.Forms.Panel();
            this.lblAzul = new System.Windows.Forms.Label();
            this.lblPos22 = new System.Windows.Forms.Label();
            this.lblPos21 = new System.Windows.Forms.Label();
            this.lblPos20 = new System.Windows.Forms.Label();
            this.lblPos19 = new System.Windows.Forms.Label();
            this.lblPos18 = new System.Windows.Forms.Label();
            this.lblPos17 = new System.Windows.Forms.Label();
            this.lblPos16 = new System.Windows.Forms.Label();
            this.lblPos15 = new System.Windows.Forms.Label();
            this.lblPos14 = new System.Windows.Forms.Label();
            this.lblPos13 = new System.Windows.Forms.Label();
            this.lblPos12 = new System.Windows.Forms.Label();
            this.lblPos11 = new System.Windows.Forms.Label();
            this.lblPos10 = new System.Windows.Forms.Label();
            this.lblPos09 = new System.Windows.Forms.Label();
            this.lblPos08 = new System.Windows.Forms.Label();
            this.lblPos07 = new System.Windows.Forms.Label();
            this.lblPos06 = new System.Windows.Forms.Label();
            this.lblPos05 = new System.Windows.Forms.Label();
            this.lblPos04 = new System.Windows.Forms.Label();
            this.lblPos03 = new System.Windows.Forms.Label();
            this.lblPos02 = new System.Windows.Forms.Label();
            this.lblPos01 = new System.Windows.Forms.Label();
            this.pnPos01 = new System.Windows.Forms.Panel();
            this.pnPos00 = new System.Windows.Forms.Panel();
            this.pnPos02 = new System.Windows.Forms.Panel();
            this.pnPos03 = new System.Windows.Forms.Panel();
            this.pnPos04 = new System.Windows.Forms.Panel();
            this.pnPos05 = new System.Windows.Forms.Panel();
            this.pnPos06 = new System.Windows.Forms.Panel();
            this.pnPos07 = new System.Windows.Forms.Panel();
            this.pnPos08 = new System.Windows.Forms.Panel();
            this.pnPos09 = new System.Windows.Forms.Panel();
            this.pnPos10 = new System.Windows.Forms.Panel();
            this.pnPos11 = new System.Windows.Forms.Panel();
            this.pnPos12 = new System.Windows.Forms.Panel();
            this.pnPos13 = new System.Windows.Forms.Panel();
            this.pnPos14 = new System.Windows.Forms.Panel();
            this.pnPos15 = new System.Windows.Forms.Panel();
            this.pnPos16 = new System.Windows.Forms.Panel();
            this.pnPos17 = new System.Windows.Forms.Panel();
            this.pnPos18 = new System.Windows.Forms.Panel();
            this.pnPos19 = new System.Windows.Forms.Panel();
            this.pnPos20 = new System.Windows.Forms.Panel();
            this.pnPos21 = new System.Windows.Forms.Panel();
            this.pnPos22 = new System.Windows.Forms.Panel();
            this.lblCarro = new System.Windows.Forms.Label();
            this.pnCarro = new System.Windows.Forms.Panel();
            this.btnBorrar = new System.Windows.Forms.Button();
            this.txtBastidor = new System.Windows.Forms.NumericUpDown();
            this.txtPrograma = new System.Windows.Forms.NumericUpDown();
            this.dtvResultados = new System.Windows.Forms.DataGridView();
            this.pbCheckCarro = new System.Windows.Forms.Button();
            this.pbCheckPosiciones = new System.Windows.Forms.Button();
            this.lblCheckCarro = new System.Windows.Forms.Label();
            this.lblCheckPosicion = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.lblTimeMaster = new System.Windows.Forms.Label();
            this.pGantt.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtBastidor)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtPrograma)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dtvResultados)).BeginInit();
            this.SuspendLayout();
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(88, 731);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(40, 13);
            this.label4.TabIndex = 397;
            this.label4.Text = "Batidor";
            // 
            // btnIntroducir
            // 
            this.btnIntroducir.Location = new System.Drawing.Point(412, 759);
            this.btnIntroducir.Name = "btnIntroducir";
            this.btnIntroducir.Size = new System.Drawing.Size(116, 29);
            this.btnIntroducir.TabIndex = 395;
            this.btnIntroducir.Text = "INTRODUCIR";
            this.btnIntroducir.UseVisualStyleBackColor = true;            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(410, 732);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(52, 13);
            this.label1.TabIndex = 399;
            this.label1.Text = "Programa";
            // 
            // pGantt
            // 
            this.pGantt.Controls.Add(this.lblResta);
            this.pGantt.Controls.Add(this.pnVerticalAzul);
            this.pGantt.Controls.Add(this.lblRojo);
            this.pGantt.Controls.Add(this.pnVerticalRoja);
            this.pGantt.Controls.Add(this.lblAzul);
            this.pGantt.Location = new System.Drawing.Point(87, 32);
            this.pGantt.Name = "pGantt";
            this.pGantt.Size = new System.Drawing.Size(1785, 690);
            this.pGantt.TabIndex = 425;
            // 
            // lblResta
            // 
            this.lblResta.AutoSize = true;
            this.lblResta.ForeColor = System.Drawing.Color.Black;
            this.lblResta.Location = new System.Drawing.Point(836, 30);
            this.lblResta.Name = "lblResta";
            this.lblResta.Size = new System.Drawing.Size(13, 13);
            this.lblResta.TabIndex = 481;
            this.lblResta.Text = "0";
            this.lblResta.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // pnVerticalAzul
            // 
            this.pnVerticalAzul.BackColor = System.Drawing.Color.Blue;
            this.pnVerticalAzul.Location = new System.Drawing.Point(314, 50);
            this.pnVerticalAzul.Name = "pnVerticalAzul";
            this.pnVerticalAzul.Size = new System.Drawing.Size(2, 600);
            this.pnVerticalAzul.TabIndex = 452;
            // 
            // lblRojo
            // 
            this.lblRojo.AutoSize = true;
            this.lblRojo.ForeColor = System.Drawing.Color.Red;
            this.lblRojo.Location = new System.Drawing.Point(871, 30);
            this.lblRojo.Name = "lblRojo";
            this.lblRojo.Size = new System.Drawing.Size(13, 13);
            this.lblRojo.TabIndex = 480;
            this.lblRojo.Text = "0";
            this.lblRojo.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // pnVerticalRoja
            // 
            this.pnVerticalRoja.BackColor = System.Drawing.Color.Red;
            this.pnVerticalRoja.Location = new System.Drawing.Point(1377, 50);
            this.pnVerticalRoja.Name = "pnVerticalRoja";
            this.pnVerticalRoja.Size = new System.Drawing.Size(2, 600);
            this.pnVerticalRoja.TabIndex = 451;

            // 
            // lblAzul
            // 
            this.lblAzul.AutoSize = true;
            this.lblAzul.ForeColor = System.Drawing.Color.Blue;
            this.lblAzul.Location = new System.Drawing.Point(801, 30);
            this.lblAzul.Name = "lblAzul";
            this.lblAzul.Size = new System.Drawing.Size(13, 13);
            this.lblAzul.TabIndex = 479;
            this.lblAzul.Text = "0";
            this.lblAzul.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // lblPos22
            // 
            this.lblPos22.AutoSize = true;
            this.lblPos22.Location = new System.Drawing.Point(20, 598);
            this.lblPos22.Name = "lblPos22";
            this.lblPos22.Size = new System.Drawing.Size(62, 13);
            this.lblPos22.TabIndex = 447;
            this.lblPos22.Text = "Posicion 22";
            // 
            // lblPos21
            // 
            this.lblPos21.AutoSize = true;
            this.lblPos21.Location = new System.Drawing.Point(20, 574);
            this.lblPos21.Name = "lblPos21";
            this.lblPos21.Size = new System.Drawing.Size(62, 13);
            this.lblPos21.TabIndex = 446;
            this.lblPos21.Text = "Posicion 21";
            // 
            // lblPos20
            // 
            this.lblPos20.AutoSize = true;
            this.lblPos20.Location = new System.Drawing.Point(20, 549);
            this.lblPos20.Name = "lblPos20";
            this.lblPos20.Size = new System.Drawing.Size(62, 13);
            this.lblPos20.TabIndex = 445;
            this.lblPos20.Text = "Posicion 20";
            // 
            // lblPos19
            // 
            this.lblPos19.AutoSize = true;
            this.lblPos19.Location = new System.Drawing.Point(20, 525);
            this.lblPos19.Name = "lblPos19";
            this.lblPos19.Size = new System.Drawing.Size(62, 13);
            this.lblPos19.TabIndex = 444;
            this.lblPos19.Text = "Posicion 19";
            // 
            // lblPos18
            // 
            this.lblPos18.AutoSize = true;
            this.lblPos18.Location = new System.Drawing.Point(20, 503);
            this.lblPos18.Name = "lblPos18";
            this.lblPos18.Size = new System.Drawing.Size(62, 13);
            this.lblPos18.TabIndex = 443;
            this.lblPos18.Text = "Posicion 18";
            // 
            // lblPos17
            // 
            this.lblPos17.AutoSize = true;
            this.lblPos17.Location = new System.Drawing.Point(20, 479);
            this.lblPos17.Name = "lblPos17";
            this.lblPos17.Size = new System.Drawing.Size(62, 13);
            this.lblPos17.TabIndex = 442;
            this.lblPos17.Text = "Posicion 17";
            // 
            // lblPos16
            // 
            this.lblPos16.AutoSize = true;
            this.lblPos16.Location = new System.Drawing.Point(20, 455);
            this.lblPos16.Name = "lblPos16";
            this.lblPos16.Size = new System.Drawing.Size(62, 13);
            this.lblPos16.TabIndex = 441;
            this.lblPos16.Text = "Posicion 16";
            // 
            // lblPos15
            // 
            this.lblPos15.AutoSize = true;
            this.lblPos15.Location = new System.Drawing.Point(20, 431);
            this.lblPos15.Name = "lblPos15";
            this.lblPos15.Size = new System.Drawing.Size(62, 13);
            this.lblPos15.TabIndex = 440;
            this.lblPos15.Text = "Posicion 15";
            // 
            // lblPos14
            // 
            this.lblPos14.AutoSize = true;
            this.lblPos14.Location = new System.Drawing.Point(20, 406);
            this.lblPos14.Name = "lblPos14";
            this.lblPos14.Size = new System.Drawing.Size(62, 13);
            this.lblPos14.TabIndex = 439;
            this.lblPos14.Text = "Posicion 14";
            // 
            // lblPos13
            // 
            this.lblPos13.AutoSize = true;
            this.lblPos13.Location = new System.Drawing.Point(20, 382);
            this.lblPos13.Name = "lblPos13";
            this.lblPos13.Size = new System.Drawing.Size(62, 13);
            this.lblPos13.TabIndex = 438;
            this.lblPos13.Text = "Posicion 13";
            // 
            // lblPos12
            // 
            this.lblPos12.AutoSize = true;
            this.lblPos12.Location = new System.Drawing.Point(20, 360);
            this.lblPos12.Name = "lblPos12";
            this.lblPos12.Size = new System.Drawing.Size(62, 13);
            this.lblPos12.TabIndex = 437;
            this.lblPos12.Text = "Posicion 12";
            // 
            // lblPos11
            // 
            this.lblPos11.AutoSize = true;
            this.lblPos11.Location = new System.Drawing.Point(20, 336);
            this.lblPos11.Name = "lblPos11";
            this.lblPos11.Size = new System.Drawing.Size(62, 13);
            this.lblPos11.TabIndex = 436;
            this.lblPos11.Text = "Posicion 11";
            // 
            // lblPos10
            // 
            this.lblPos10.AutoSize = true;
            this.lblPos10.Location = new System.Drawing.Point(20, 311);
            this.lblPos10.Name = "lblPos10";
            this.lblPos10.Size = new System.Drawing.Size(62, 13);
            this.lblPos10.TabIndex = 435;
            this.lblPos10.Text = "Posicion 10";
            // 
            // lblPos09
            // 
            this.lblPos09.AutoSize = true;
            this.lblPos09.Location = new System.Drawing.Point(20, 287);
            this.lblPos09.Name = "lblPos09";
            this.lblPos09.Size = new System.Drawing.Size(62, 13);
            this.lblPos09.TabIndex = 434;
            this.lblPos09.Text = "Posicion 09";
            // 
            // lblPos08
            // 
            this.lblPos08.AutoSize = true;
            this.lblPos08.Location = new System.Drawing.Point(20, 264);
            this.lblPos08.Name = "lblPos08";
            this.lblPos08.Size = new System.Drawing.Size(62, 13);
            this.lblPos08.TabIndex = 433;
            this.lblPos08.Text = "Posicion 08";
            // 
            // lblPos07
            // 
            this.lblPos07.AutoSize = true;
            this.lblPos07.Location = new System.Drawing.Point(20, 240);
            this.lblPos07.Name = "lblPos07";
            this.lblPos07.Size = new System.Drawing.Size(62, 13);
            this.lblPos07.TabIndex = 432;
            this.lblPos07.Text = "Posicion 07";
            // 
            // lblPos06
            // 
            this.lblPos06.AutoSize = true;
            this.lblPos06.Location = new System.Drawing.Point(20, 215);
            this.lblPos06.Name = "lblPos06";
            this.lblPos06.Size = new System.Drawing.Size(62, 13);
            this.lblPos06.TabIndex = 431;
            this.lblPos06.Text = "Posicion 06";
            // 
            // lblPos05
            // 
            this.lblPos05.AutoSize = true;
            this.lblPos05.Location = new System.Drawing.Point(20, 191);
            this.lblPos05.Name = "lblPos05";
            this.lblPos05.Size = new System.Drawing.Size(62, 13);
            this.lblPos05.TabIndex = 430;
            this.lblPos05.Text = "Posicion 05";
            // 
            // lblPos04
            // 
            this.lblPos04.AutoSize = true;
            this.lblPos04.Location = new System.Drawing.Point(20, 169);
            this.lblPos04.Name = "lblPos04";
            this.lblPos04.Size = new System.Drawing.Size(62, 13);
            this.lblPos04.TabIndex = 429;
            this.lblPos04.Text = "Posicion 04";
            // 
            // lblPos03
            // 
            this.lblPos03.AutoSize = true;
            this.lblPos03.Location = new System.Drawing.Point(20, 145);
            this.lblPos03.Name = "lblPos03";
            this.lblPos03.Size = new System.Drawing.Size(62, 13);
            this.lblPos03.TabIndex = 428;
            this.lblPos03.Text = "Posicion 03";
            // 
            // lblPos02
            // 
            this.lblPos02.AutoSize = true;
            this.lblPos02.Location = new System.Drawing.Point(20, 120);
            this.lblPos02.Name = "lblPos02";
            this.lblPos02.Size = new System.Drawing.Size(62, 13);
            this.lblPos02.TabIndex = 427;
            this.lblPos02.Text = "Posicion 02";
            // 
            // lblPos01
            // 
            this.lblPos01.AutoSize = true;
            this.lblPos01.Location = new System.Drawing.Point(20, 96);
            this.lblPos01.Name = "lblPos01";
            this.lblPos01.Size = new System.Drawing.Size(62, 13);
            this.lblPos01.TabIndex = 426;
            this.lblPos01.Text = "Posicion 01";
            // 
            // pnPos01
            // 
            this.pnPos01.BackColor = System.Drawing.Color.Black;
            this.pnPos01.Location = new System.Drawing.Point(23, 114);
            this.pnPos01.Name = "pnPos01";
            this.pnPos01.Size = new System.Drawing.Size(1855, 1);
            this.pnPos01.TabIndex = 448;
            // 
            // pnPos00
            // 
            this.pnPos00.BackColor = System.Drawing.Color.Black;
            this.pnPos00.Location = new System.Drawing.Point(23, 91);
            this.pnPos00.Name = "pnPos00";
            this.pnPos00.Size = new System.Drawing.Size(1855, 1);
            this.pnPos00.TabIndex = 449;
            // 
            // pnPos02
            // 
            this.pnPos02.BackColor = System.Drawing.Color.Black;
            this.pnPos02.Location = new System.Drawing.Point(23, 140);
            this.pnPos02.Name = "pnPos02";
            this.pnPos02.Size = new System.Drawing.Size(1855, 1);
            this.pnPos02.TabIndex = 449;
            // 
            // pnPos03
            // 
            this.pnPos03.BackColor = System.Drawing.Color.Black;
            this.pnPos03.Location = new System.Drawing.Point(23, 164);
            this.pnPos03.Name = "pnPos03";
            this.pnPos03.Size = new System.Drawing.Size(1855, 1);
            this.pnPos03.TabIndex = 449;
            // 
            // pnPos04
            // 
            this.pnPos04.BackColor = System.Drawing.Color.Black;
            this.pnPos04.Location = new System.Drawing.Point(23, 185);
            this.pnPos04.Name = "pnPos04";
            this.pnPos04.Size = new System.Drawing.Size(1855, 1);
            this.pnPos04.TabIndex = 449;
            // 
            // pnPos05
            // 
            this.pnPos05.BackColor = System.Drawing.Color.Black;
            this.pnPos05.Location = new System.Drawing.Point(23, 207);
            this.pnPos05.Name = "pnPos05";
            this.pnPos05.Size = new System.Drawing.Size(1855, 1);
            this.pnPos05.TabIndex = 449;
            // 
            // pnPos06
            // 
            this.pnPos06.BackColor = System.Drawing.Color.Black;
            this.pnPos06.Location = new System.Drawing.Point(23, 235);
            this.pnPos06.Name = "pnPos06";
            this.pnPos06.Size = new System.Drawing.Size(1855, 1);
            this.pnPos06.TabIndex = 449;
            // 
            // pnPos07
            // 
            this.pnPos07.BackColor = System.Drawing.Color.Black;
            this.pnPos07.Location = new System.Drawing.Point(23, 259);
            this.pnPos07.Name = "pnPos07";
            this.pnPos07.Size = new System.Drawing.Size(1855, 1);
            this.pnPos07.TabIndex = 449;
            // 
            // pnPos08
            // 
            this.pnPos08.BackColor = System.Drawing.Color.Black;
            this.pnPos08.Location = new System.Drawing.Point(23, 282);
            this.pnPos08.Name = "pnPos08";
            this.pnPos08.Size = new System.Drawing.Size(1855, 1);
            this.pnPos08.TabIndex = 449;
            // 
            // pnPos09
            // 
            this.pnPos09.BackColor = System.Drawing.Color.Black;
            this.pnPos09.Location = new System.Drawing.Point(23, 306);
            this.pnPos09.Name = "pnPos09";
            this.pnPos09.Size = new System.Drawing.Size(1855, 1);
            this.pnPos09.TabIndex = 449;
            // 
            // pnPos10
            // 
            this.pnPos10.BackColor = System.Drawing.Color.Black;
            this.pnPos10.Location = new System.Drawing.Point(23, 331);
            this.pnPos10.Name = "pnPos10";
            this.pnPos10.Size = new System.Drawing.Size(1855, 1);
            this.pnPos10.TabIndex = 449;
            // 
            // pnPos11
            // 
            this.pnPos11.BackColor = System.Drawing.Color.Black;
            this.pnPos11.Location = new System.Drawing.Point(23, 355);
            this.pnPos11.Name = "pnPos11";
            this.pnPos11.Size = new System.Drawing.Size(1855, 1);
            this.pnPos11.TabIndex = 449;
            // 
            // pnPos12
            // 
            this.pnPos12.BackColor = System.Drawing.Color.Black;
            this.pnPos12.Location = new System.Drawing.Point(23, 377);
            this.pnPos12.Name = "pnPos12";
            this.pnPos12.Size = new System.Drawing.Size(1855, 1);
            this.pnPos12.TabIndex = 449;
            // 
            // pnPos13
            // 
            this.pnPos13.BackColor = System.Drawing.Color.Black;
            this.pnPos13.Location = new System.Drawing.Point(23, 401);
            this.pnPos13.Name = "pnPos13";
            this.pnPos13.Size = new System.Drawing.Size(1855, 1);
            this.pnPos13.TabIndex = 449;
            // 
            // pnPos14
            // 
            this.pnPos14.BackColor = System.Drawing.Color.Black;
            this.pnPos14.Location = new System.Drawing.Point(23, 426);
            this.pnPos14.Name = "pnPos14";
            this.pnPos14.Size = new System.Drawing.Size(1855, 1);
            this.pnPos14.TabIndex = 449;
            // 
            // pnPos15
            // 
            this.pnPos15.BackColor = System.Drawing.Color.Black;
            this.pnPos15.Location = new System.Drawing.Point(23, 447);
            this.pnPos15.Name = "pnPos15";
            this.pnPos15.Size = new System.Drawing.Size(1855, 1);
            this.pnPos15.TabIndex = 449;
            // 
            // pnPos16
            // 
            this.pnPos16.BackColor = System.Drawing.Color.Black;
            this.pnPos16.Location = new System.Drawing.Point(23, 474);
            this.pnPos16.Name = "pnPos16";
            this.pnPos16.Size = new System.Drawing.Size(1855, 1);
            this.pnPos16.TabIndex = 449;
            // 
            // pnPos17
            // 
            this.pnPos17.BackColor = System.Drawing.Color.Black;
            this.pnPos17.Location = new System.Drawing.Point(23, 498);
            this.pnPos17.Name = "pnPos17";
            this.pnPos17.Size = new System.Drawing.Size(1855, 1);
            this.pnPos17.TabIndex = 449;
            // 
            // pnPos18
            // 
            this.pnPos18.BackColor = System.Drawing.Color.Black;
            this.pnPos18.Location = new System.Drawing.Point(23, 520);
            this.pnPos18.Name = "pnPos18";
            this.pnPos18.Size = new System.Drawing.Size(1855, 1);
            this.pnPos18.TabIndex = 449;
            // 
            // pnPos19
            // 
            this.pnPos19.BackColor = System.Drawing.Color.Black;
            this.pnPos19.Location = new System.Drawing.Point(23, 544);
            this.pnPos19.Name = "pnPos19";
            this.pnPos19.Size = new System.Drawing.Size(1855, 1);
            this.pnPos19.TabIndex = 449;
            // 
            // pnPos20
            // 
            this.pnPos20.BackColor = System.Drawing.Color.Black;
            this.pnPos20.Location = new System.Drawing.Point(23, 569);
            this.pnPos20.Name = "pnPos20";
            this.pnPos20.Size = new System.Drawing.Size(1855, 1);
            this.pnPos20.TabIndex = 449;
            // 
            // pnPos21
            // 
            this.pnPos21.BackColor = System.Drawing.Color.Black;
            this.pnPos21.Location = new System.Drawing.Point(23, 593);
            this.pnPos21.Name = "pnPos21";
            this.pnPos21.Size = new System.Drawing.Size(1855, 1);
            this.pnPos21.TabIndex = 449;
            // 
            // pnPos22
            // 
            this.pnPos22.BackColor = System.Drawing.Color.Blue;
            this.pnPos22.Location = new System.Drawing.Point(23, 614);
            this.pnPos22.Name = "pnPos22";
            this.pnPos22.Size = new System.Drawing.Size(1855, 1);
            this.pnPos22.TabIndex = 449;
            // 
            // lblCarro
            // 
            this.lblCarro.AutoSize = true;
            this.lblCarro.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCarro.ForeColor = System.Drawing.Color.Blue;
            this.lblCarro.Location = new System.Drawing.Point(20, 619);
            this.lblCarro.Name = "lblCarro";
            this.lblCarro.Size = new System.Drawing.Size(50, 13);
            this.lblCarro.TabIndex = 450;
            this.lblCarro.Text = "CARRO";
            // 
            // pnCarro
            // 
            this.pnCarro.BackColor = System.Drawing.Color.Blue;
            this.pnCarro.Location = new System.Drawing.Point(23, 635);
            this.pnCarro.Name = "pnCarro";
            this.pnCarro.Size = new System.Drawing.Size(1855, 1);
            this.pnCarro.TabIndex = 450;
            // 
            // btnBorrar
            // 
            this.btnBorrar.Location = new System.Drawing.Point(412, 806);
            this.btnBorrar.Name = "btnBorrar";
            this.btnBorrar.Size = new System.Drawing.Size(116, 29);
            this.btnBorrar.TabIndex = 452;
            this.btnBorrar.Text = "BORRAR";
            this.btnBorrar.UseVisualStyleBackColor = true;
            // 
            // txtBastidor
            // 
            this.txtBastidor.Location = new System.Drawing.Point(151, 729);
            this.txtBastidor.Maximum = new decimal(new int[] {
            6,
            0,
            0,
            0});
            this.txtBastidor.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.txtBastidor.Name = "txtBastidor";
            this.txtBastidor.Size = new System.Drawing.Size(56, 20);
            this.txtBastidor.TabIndex = 453;
            this.txtBastidor.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtBastidor.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // txtPrograma
            // 
            this.txtPrograma.Location = new System.Drawing.Point(472, 729);
            this.txtPrograma.Maximum = new decimal(new int[] {
            5,
            0,
            0,
            0});
            this.txtPrograma.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.txtPrograma.Name = "txtPrograma";
            this.txtPrograma.Size = new System.Drawing.Size(56, 20);
            this.txtPrograma.TabIndex = 454;
            this.txtPrograma.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtPrograma.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // dtvResultados
            // 
            this.dtvResultados.AllowUserToAddRows = false;
            this.dtvResultados.AllowUserToDeleteRows = false;
            this.dtvResultados.AllowUserToResizeColumns = false;
            this.dtvResultados.AllowUserToResizeRows = false;
            this.dtvResultados.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dtvResultados.Location = new System.Drawing.Point(565, 732);
            this.dtvResultados.MultiSelect = false;
            this.dtvResultados.Name = "dtvResultados";
            this.dtvResultados.ReadOnly = true;
            this.dtvResultados.Size = new System.Drawing.Size(716, 161);
            this.dtvResultados.TabIndex = 478;
            // 
            // pbCheckCarro
            // 
            this.pbCheckCarro.Location = new System.Drawing.Point(1307, 759);
            this.pbCheckCarro.Name = "pbCheckCarro";
            this.pbCheckCarro.Size = new System.Drawing.Size(116, 29);
            this.pbCheckCarro.TabIndex = 479;
            this.pbCheckCarro.Text = "CHECK CARRO";
            this.pbCheckCarro.UseVisualStyleBackColor = true;
            // 
            // pbCheckPosiciones
            // 
            this.pbCheckPosiciones.Location = new System.Drawing.Point(1307, 806);
            this.pbCheckPosiciones.Name = "pbCheckPosiciones";
            this.pbCheckPosiciones.Size = new System.Drawing.Size(116, 29);
            this.pbCheckPosiciones.TabIndex = 480;
            this.pbCheckPosiciones.Text = "CHECK POSICION";
            this.pbCheckPosiciones.UseVisualStyleBackColor = true;
            // 
            // lblCheckCarro
            // 
            this.lblCheckCarro.AutoSize = true;
            this.lblCheckCarro.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCheckCarro.Location = new System.Drawing.Point(1435, 762);
            this.lblCheckCarro.Name = "lblCheckCarro";
            this.lblCheckCarro.Size = new System.Drawing.Size(39, 24);
            this.lblCheckCarro.TabIndex = 481;
            this.lblCheckCarro.Text = "OK";
            // 
            // lblCheckPosicion
            // 
            this.lblCheckPosicion.AutoSize = true;
            this.lblCheckPosicion.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCheckPosicion.Location = new System.Drawing.Point(1435, 806);
            this.lblCheckPosicion.Name = "lblCheckPosicion";
            this.lblCheckPosicion.Size = new System.Drawing.Size(39, 24);
            this.lblCheckPosicion.TabIndex = 488;
            this.lblCheckPosicion.Text = "OK";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(811, 930);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(96, 20);
            this.label6.TabIndex = 462;
            this.label6.Text = "TimeMaster:";
            // 
            // lblTimeMaster
            // 
            this.lblTimeMaster.AutoSize = true;
            this.lblTimeMaster.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTimeMaster.Location = new System.Drawing.Point(904, 928);
            this.lblTimeMaster.Name = "lblTimeMaster";
            this.lblTimeMaster.Size = new System.Drawing.Size(119, 24);
            this.lblTimeMaster.TabIndex = 477;
            this.lblTimeMaster.Text = "TimeMaster";
            // 
            // Form_Introducir
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1884, 961);
            this.ControlBox = false;
            this.Controls.Add(this.lblCheckPosicion);
            this.Controls.Add(this.lblCheckCarro);
            this.Controls.Add(this.pbCheckPosiciones);
            this.Controls.Add(this.pbCheckCarro);
            this.Controls.Add(this.dtvResultados);
            this.Controls.Add(this.lblTimeMaster);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.txtPrograma);
            this.Controls.Add(this.txtBastidor);
            this.Controls.Add(this.btnBorrar);
            this.Controls.Add(this.pnCarro);
            this.Controls.Add(this.lblCarro);
            this.Controls.Add(this.pnPos22);
            this.Controls.Add(this.pnPos21);
            this.Controls.Add(this.pnPos20);
            this.Controls.Add(this.pnPos19);
            this.Controls.Add(this.pnPos18);
            this.Controls.Add(this.pnPos17);
            this.Controls.Add(this.pnPos16);
            this.Controls.Add(this.pnPos15);
            this.Controls.Add(this.pnPos14);
            this.Controls.Add(this.pnPos13);
            this.Controls.Add(this.pnPos12);
            this.Controls.Add(this.pnPos11);
            this.Controls.Add(this.pnPos10);
            this.Controls.Add(this.pnPos09);
            this.Controls.Add(this.pnPos08);
            this.Controls.Add(this.pnPos07);
            this.Controls.Add(this.pnPos06);
            this.Controls.Add(this.pnPos05);
            this.Controls.Add(this.pnPos04);
            this.Controls.Add(this.pnPos03);
            this.Controls.Add(this.pnPos02);
            this.Controls.Add(this.pnPos00);
            this.Controls.Add(this.pnPos01);
            this.Controls.Add(this.lblPos22);
            this.Controls.Add(this.lblPos21);
            this.Controls.Add(this.lblPos20);
            this.Controls.Add(this.lblPos19);
            this.Controls.Add(this.lblPos18);
            this.Controls.Add(this.lblPos17);
            this.Controls.Add(this.lblPos16);
            this.Controls.Add(this.lblPos15);
            this.Controls.Add(this.lblPos14);
            this.Controls.Add(this.lblPos13);
            this.Controls.Add(this.lblPos12);
            this.Controls.Add(this.lblPos11);
            this.Controls.Add(this.lblPos10);
            this.Controls.Add(this.lblPos09);
            this.Controls.Add(this.lblPos08);
            this.Controls.Add(this.lblPos07);
            this.Controls.Add(this.lblPos06);
            this.Controls.Add(this.lblPos05);
            this.Controls.Add(this.lblPos04);
            this.Controls.Add(this.lblPos03);
            this.Controls.Add(this.lblPos02);
            this.Controls.Add(this.lblPos01);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.btnIntroducir);
            this.Controls.Add(this.pGantt);
            this.Name = "Form_Introducir";
            this.ShowIcon = false;
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "PRODUCCIÓN";
            this.pGantt.ResumeLayout(false);
            this.pGantt.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtBastidor)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtPrograma)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dtvResultados)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button btnIntroducir;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel pGantt;
        private System.Windows.Forms.Label lblPos22;
        private System.Windows.Forms.Label lblPos21;
        private System.Windows.Forms.Label lblPos20;
        private System.Windows.Forms.Label lblPos19;
        private System.Windows.Forms.Label lblPos18;
        private System.Windows.Forms.Label lblPos17;
        private System.Windows.Forms.Label lblPos16;
        private System.Windows.Forms.Label lblPos15;
        private System.Windows.Forms.Label lblPos14;
        private System.Windows.Forms.Label lblPos13;
        private System.Windows.Forms.Label lblPos12;
        private System.Windows.Forms.Label lblPos11;
        private System.Windows.Forms.Label lblPos10;
        private System.Windows.Forms.Label lblPos09;
        private System.Windows.Forms.Label lblPos08;
        private System.Windows.Forms.Label lblPos07;
        private System.Windows.Forms.Label lblPos06;
        private System.Windows.Forms.Label lblPos05;
        private System.Windows.Forms.Label lblPos04;
        private System.Windows.Forms.Label lblPos03;
        private System.Windows.Forms.Label lblPos02;
        private System.Windows.Forms.Label lblPos01;
        private System.Windows.Forms.Panel pnPos01;
        private System.Windows.Forms.Panel pnPos00;
        private System.Windows.Forms.Panel pnPos02;
        private System.Windows.Forms.Panel pnPos03;
        private System.Windows.Forms.Panel pnPos04;
        private System.Windows.Forms.Panel pnPos05;
        private System.Windows.Forms.Panel pnPos06;
        private System.Windows.Forms.Panel pnPos07;
        private System.Windows.Forms.Panel pnPos08;
        private System.Windows.Forms.Panel pnPos09;
        private System.Windows.Forms.Panel pnPos10;
        private System.Windows.Forms.Panel pnPos11;
        private System.Windows.Forms.Panel pnPos12;
        private System.Windows.Forms.Panel pnPos13;
        private System.Windows.Forms.Panel pnPos14;
        private System.Windows.Forms.Panel pnPos15;
        private System.Windows.Forms.Panel pnPos16;
        private System.Windows.Forms.Panel pnPos17;
        private System.Windows.Forms.Panel pnPos18;
        private System.Windows.Forms.Panel pnPos19;
        private System.Windows.Forms.Panel pnPos20;
        private System.Windows.Forms.Panel pnPos21;
        private System.Windows.Forms.Panel pnPos22;
        private System.Windows.Forms.Label lblCarro;
        private System.Windows.Forms.Panel pnCarro;
        private System.Windows.Forms.Panel pnVerticalRoja;
        private System.Windows.Forms.Button btnBorrar;
        private System.Windows.Forms.NumericUpDown txtBastidor;
        private System.Windows.Forms.NumericUpDown txtPrograma;
        private System.Windows.Forms.Panel pnVerticalAzul;
        private System.Windows.Forms.Label lblResta;
        private System.Windows.Forms.Label lblRojo;
        private System.Windows.Forms.Label lblAzul;
        private System.Windows.Forms.DataGridView dtvResultados;
        private System.Windows.Forms.Button pbCheckCarro;
        private System.Windows.Forms.Button pbCheckPosiciones;
        private System.Windows.Forms.Label lblCheckCarro;
        private System.Windows.Forms.Label lblCheckPosicion;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label lblTimeMaster;
    }
}