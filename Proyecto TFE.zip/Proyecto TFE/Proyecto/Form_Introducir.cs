﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;
using static Proyecto.Program;
using System.Drawing.Drawing2D;
using System.Reflection.Emit;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using System.Threading;


namespace Proyecto
{
    public partial class Form_Introducir : Form
    {

        public OleDbConnection cn1;
        public System.Data.OleDb.OleDbCommand Comando1;
        public System.Data.OleDb.OleDbDataReader lector1;

        public OleDbConnection cn2;
        public System.Data.OleDb.OleDbCommand Comando2;
        public System.Data.OleDb.OleDbDataReader lector2;

        private bool isDraggingRojo = false;
        private bool isDraggingAzul = false;
        Point inicial;

        public decimal ActualLineaRoja;
        public decimal ActualLineaAzul;

        public struct CarroActualStruct
        {
            public int CarroActual;
            public int CarroActualNext;
        }

        public struct PosicionLibreStruct
        {
            public int Ampliar;
            public int TiempoEstancia;
        }

        public Form_Introducir()
        {
            InitializeComponent();
            //Rellenar_Desplazamientos();
            //Rellenar_Procesos();
            


        }




    }
}
