﻿namespace Proyecto
{
    partial class Form_MDI
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.pLANIFICADORToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pOSICIONESToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.dESPLAZAMIENTOSToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.iNTRODUCIRToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.panel1 = new System.Windows.Forms.Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pROGRAMADETALLEToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pROGRAMAGENERALToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.pLANIFICADORToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1904, 24);
            this.menuStrip1.TabIndex = 1;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // pLANIFICADORToolStripMenuItem
            // 
            this.pLANIFICADORToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.pOSICIONESToolStripMenuItem,
            this.pROGRAMAGENERALToolStripMenuItem,
            this.pROGRAMADETALLEToolStripMenuItem,
            this.dESPLAZAMIENTOSToolStripMenuItem,
            this.iNTRODUCIRToolStripMenuItem});
            this.pLANIFICADORToolStripMenuItem.Name = "pLANIFICADORToolStripMenuItem";
            this.pLANIFICADORToolStripMenuItem.Size = new System.Drawing.Size(101, 20);
            this.pLANIFICADORToolStripMenuItem.Text = "PLANIFICADOR";
            // 
            // pOSICIONESToolStripMenuItem
            // 
            this.pOSICIONESToolStripMenuItem.Name = "pOSICIONESToolStripMenuItem";
            this.pOSICIONESToolStripMenuItem.Size = new System.Drawing.Size(192, 22);
            this.pOSICIONESToolStripMenuItem.Text = "POSICIONES";
            this.pOSICIONESToolStripMenuItem.Click += new System.EventHandler(this.pOSICIONESToolStripMenuItem_Click);
            // 
            // dESPLAZAMIENTOSToolStripMenuItem
            // 
            this.dESPLAZAMIENTOSToolStripMenuItem.Name = "dESPLAZAMIENTOSToolStripMenuItem";
            this.dESPLAZAMIENTOSToolStripMenuItem.Size = new System.Drawing.Size(192, 22);
            this.dESPLAZAMIENTOSToolStripMenuItem.Text = "DESPLAZAMIENTOS";
            this.dESPLAZAMIENTOSToolStripMenuItem.Click += new System.EventHandler(this.dESPLAZAMIENTOSToolStripMenuItem_Click);
            // 
            // iNTRODUCIRToolStripMenuItem
            // 
            this.iNTRODUCIRToolStripMenuItem.Name = "iNTRODUCIRToolStripMenuItem";
            this.iNTRODUCIRToolStripMenuItem.Size = new System.Drawing.Size(192, 22);
            this.iNTRODUCIRToolStripMenuItem.Text = "PRODUCCION";
            this.iNTRODUCIRToolStripMenuItem.Click += new System.EventHandler(this.iNTRODUCIRToolStripMenuItem_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.White;
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Location = new System.Drawing.Point(2, 27);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1903, 52);
            this.panel1.TabIndex = 3;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::Proyecto.Properties.Resources.unir;
            this.pictureBox1.Location = new System.Drawing.Point(11, 3);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(187, 46);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // pROGRAMADETALLEToolStripMenuItem
            // 
            this.pROGRAMADETALLEToolStripMenuItem.Name = "pROGRAMADETALLEToolStripMenuItem";
            this.pROGRAMADETALLEToolStripMenuItem.Size = new System.Drawing.Size(192, 22);
            this.pROGRAMADETALLEToolStripMenuItem.Text = "PROGRAMA DETALLE";
            this.pROGRAMADETALLEToolStripMenuItem.Click += new System.EventHandler(this.dETALLEToolStripMenuItem_Click);
            // 
            // pROGRAMAGENERALToolStripMenuItem
            // 
            this.pROGRAMAGENERALToolStripMenuItem.Name = "pROGRAMAGENERALToolStripMenuItem";
            this.pROGRAMAGENERALToolStripMenuItem.Size = new System.Drawing.Size(192, 22);
            this.pROGRAMAGENERALToolStripMenuItem.Text = "PROGRAMA GENERAL";
            this.pROGRAMAGENERALToolStripMenuItem.Click += new System.EventHandler(this.gENERALToolStripMenuItem_Click);
            // 
            // Form_MDI
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1904, 1011);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.menuStrip1);
            this.IsMdiContainer = true;
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form_MDI";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Proyecto (Andoni Puente Fernández)";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.Form_MDI_FormClosed);
            this.Load += new System.EventHandler(this.Form_MDI_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem pLANIFICADORToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem dESPLAZAMIENTOSToolStripMenuItem;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.ToolStripMenuItem pOSICIONESToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem iNTRODUCIRToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem pROGRAMAGENERALToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem pROGRAMADETALLEToolStripMenuItem;
    }
}

