﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Proyecto
{
    public partial class Form_MDI : Form
    {
        public Form_MDI()
        {
            InitializeComponent();
        }



        private void Form_MDI_Load(object sender, EventArgs e)
        {
            Program._oDesplazamientos = new Form_Desplazamientos();
            Program._oDesplazamientos.MdiParent = this;
            Program._oDesplazamientos.WindowState = FormWindowState.Maximized;

            Program._oProgramas = new Form_Programa();
            Program._oProgramas.MdiParent = this;
            Program._oProgramas.WindowState = FormWindowState.Maximized;

            Program._oProgramaDetalle = new Form_Programa_Detalle();
            Program._oProgramaDetalle.MdiParent = this;
            Program._oProgramaDetalle.WindowState = FormWindowState.Maximized;

            Program._oPosiciones = new Form_Posiciones();
            Program._oPosiciones.MdiParent = this;
            Program._oPosiciones.WindowState = FormWindowState.Maximized;

            Program._oIntroducir = new Form_Introducir();
            Program._oIntroducir.MdiParent = this;
            Program._oIntroducir.WindowState = FormWindowState.Maximized;
        }

        private void Form_MDI_FormClosed(object sender, FormClosedEventArgs e)
        {
            Program._oDesplazamientos.Close();
            Program._oProgramas.Close();
            Program._oProgramaDetalle.Close();
            Program._oPosiciones.Close();
            Program._oIntroducir.Close();
        }

        private void dESPLAZAMIENTOSToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Program._oProgramas.Hide();
            Program._oProgramaDetalle.Hide();
            Program._oPosiciones.Hide();
            Program._oIntroducir.Hide();

            Program._oDesplazamientos.Show();
        }

        private void gENERALToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Program._oDesplazamientos.Hide();
            Program._oProgramaDetalle.Hide();
            Program._oPosiciones.Hide();
            Program._oIntroducir.Hide();

            Program._oProgramas.Show();
        }

        private void dETALLEToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Program._oDesplazamientos.Hide();
            Program._oProgramas.Hide();
            Program._oPosiciones.Hide();
            Program._oIntroducir.Hide();

            Program._oProgramaDetalle.Show();
        }

        private void pOSICIONESToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Program._oDesplazamientos.Hide();
            Program._oProgramas.Hide();
            Program._oProgramaDetalle.Hide();
            Program._oIntroducir.Hide();

            Program._oPosiciones.Show();
        }
        private void iNTRODUCIRToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Program._oDesplazamientos.Hide();
            Program._oProgramas.Hide();
            Program._oProgramaDetalle.Hide();
            Program._oPosiciones.Hide();

            Program._oIntroducir.Show();
        }
    }
}
