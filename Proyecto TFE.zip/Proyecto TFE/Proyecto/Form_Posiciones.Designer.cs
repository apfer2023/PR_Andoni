﻿namespace Proyecto
{
    partial class Form_Posiciones
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label2 = new System.Windows.Forms.Label();
            this.txtNumPosicion = new System.Windows.Forms.TextBox();
            this.txtNomPosicion = new System.Windows.Forms.TextBox();
            this.btnEditar = new System.Windows.Forms.Button();
            this.btnGUARDAR = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.lblPosOrigen = new System.Windows.Forms.Label();
            this.btnRefrescar = new System.Windows.Forms.Button();
            this.label12 = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(98, 663);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(150, 13);
            this.label2.TabIndex = 185;
            this.label2.Text = "Sintaxis: POS XX. NNNNNNN";
            // 
            // txtNumPosicion
            // 
            this.txtNumPosicion.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNumPosicion.Location = new System.Drawing.Point(61, 714);
            this.txtNumPosicion.Name = "txtNumPosicion";
            this.txtNumPosicion.ReadOnly = true;
            this.txtNumPosicion.Size = new System.Drawing.Size(29, 22);
            this.txtNumPosicion.TabIndex = 184;
            this.txtNumPosicion.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtNomPosicion
            // 
            this.txtNomPosicion.Location = new System.Drawing.Point(98, 717);
            this.txtNomPosicion.MaxLength = 29;
            this.txtNomPosicion.Name = "txtNomPosicion";
            this.txtNomPosicion.Size = new System.Drawing.Size(165, 20);
            this.txtNomPosicion.TabIndex = 183;
            // 
            // btnEditar
            // 
            this.btnEditar.Location = new System.Drawing.Point(53, 756);
            this.btnEditar.Name = "btnEditar";
            this.btnEditar.Size = new System.Drawing.Size(100, 30);
            this.btnEditar.TabIndex = 182;
            this.btnEditar.Text = "EDITAR";
            this.btnEditar.UseVisualStyleBackColor = true;
            this.btnEditar.Click += new System.EventHandler(this.btnEditar_Click);
            // 
            // btnGUARDAR
            // 
            this.btnGUARDAR.Location = new System.Drawing.Point(163, 756);
            this.btnGUARDAR.Name = "btnGUARDAR";
            this.btnGUARDAR.Size = new System.Drawing.Size(100, 30);
            this.btnGUARDAR.TabIndex = 181;
            this.btnGUARDAR.Text = "GUARDAR";
            this.btnGUARDAR.UseVisualStyleBackColor = true;
            this.btnGUARDAR.Click += new System.EventHandler(this.btnGUARDAR_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(98, 699);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(87, 13);
            this.label1.TabIndex = 180;
            this.label1.Text = "Nombre Posición";
            // 
            // lblPosOrigen
            // 
            this.lblPosOrigen.AutoSize = true;
            this.lblPosOrigen.Location = new System.Drawing.Point(68, 697);
            this.lblPosOrigen.Name = "lblPosOrigen";
            this.lblPosOrigen.Size = new System.Drawing.Size(19, 13);
            this.lblPosOrigen.TabIndex = 179;
            this.lblPosOrigen.Text = "Nª";
            // 
            // btnRefrescar
            // 
            this.btnRefrescar.Location = new System.Drawing.Point(12, 98);
            this.btnRefrescar.Name = "btnRefrescar";
            this.btnRefrescar.Size = new System.Drawing.Size(174, 29);
            this.btnRefrescar.TabIndex = 178;
            this.btnRefrescar.Text = "REFRESCAR";
            this.btnRefrescar.UseVisualStyleBackColor = true;
            this.btnRefrescar.Click += new System.EventHandler(this.btnRefrescar_Click);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(194, 107);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(127, 13);
            this.label12.TabIndex = 177;
            this.label12.Text = "TABLA DE POSICIONES";
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(12, 133);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.Size = new System.Drawing.Size(308, 511);
            this.dataGridView1.TabIndex = 176;
            this.dataGridView1.RowEnter += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_RowEnter);
            // 
            // Form_Posiciones
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1884, 961);
            this.ControlBox = false;
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txtNumPosicion);
            this.Controls.Add(this.txtNomPosicion);
            this.Controls.Add(this.btnEditar);
            this.Controls.Add(this.btnGUARDAR);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lblPosOrigen);
            this.Controls.Add(this.btnRefrescar);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.dataGridView1);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Form_Posiciones";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "POSICIONES";
            this.Load += new System.EventHandler(this.Form_Posiciones_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtNumPosicion;
        private System.Windows.Forms.TextBox txtNomPosicion;
        private System.Windows.Forms.Button btnEditar;
        private System.Windows.Forms.Button btnGUARDAR;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblPosOrigen;
        private System.Windows.Forms.Button btnRefrescar;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.DataGridView dataGridView1;
    }
}