﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;

namespace Proyecto
{
    public partial class Form_Posiciones : Form
    {

        public string EstadoConexion;
        public OleDbConnection cn1;
        public OleDbConnection cn2;
        public string MiSelectGeneral;
        public DataSet dsGeneral;
        public DataTable dtGeneral;
        public DataRow drGeneral;
        public OleDbDataAdapter caGeneral;
        public System.Data.OleDb.OleDbCommand Comando2;

        public int filaselec;
        public string PosicionModificada;
        public bool habilitar;


        public Form_Posiciones()
        {
            InitializeComponent();
            habilitar = false;
            PosicionModificada = "";
            txtNomPosicion.Enabled = false;
            btnGUARDAR.Enabled = false;
        }

        public void RellenarGridGeneral()
        {
            int b = 0;
            cn1 = new OleDbConnection(Program.CadenaConexion);

            EstadoConexion = Convert.ToString(cn1.State);
            try
            {
                txtNomPosicion.Enabled = false;

                MiSelectGeneral = "SELECT * FROM Posiciones ORDER BY NumPosicion ASC";
                dataGridView1.Rows.Clear();
                dsGeneral = new System.Data.DataSet();
                dtGeneral = new System.Data.DataTable();
                caGeneral = new OleDbDataAdapter(MiSelectGeneral, cn1);
                caGeneral.Fill(dsGeneral, "GENERALGRID");
                dataGridView1.AutoGenerateColumns = false;
                dataGridView1.ColumnCount = 2;
                dtGeneral = dsGeneral.Tables[0];

                dataGridView1.Columns[0].Name = "NUM";
                dataGridView1.Columns[1].Name = "NOMBRE POSICION";

                dataGridView1.Columns["NUM"].SortMode = DataGridViewColumnSortMode.NotSortable;
                dataGridView1.Columns["NOMBRE POSICION"].SortMode = DataGridViewColumnSortMode.NotSortable;

                dataGridView1.Columns["NUM"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
                dataGridView1.Columns["NOMBRE POSICION"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;

                dataGridView1.Columns["NUM"].Width = 60;
                dataGridView1.Columns["NOMBRE POSICION"].Width = 200;

                if (dtGeneral.Rows.Count > 0)
                {
                    dataGridView1.Rows.Add(dtGeneral.Rows.Count);
                }

                if (dtGeneral.Rows.Count > 0)
                {

                    for (b = 0; b < dtGeneral.Rows.Count; b++)
                    {
                        drGeneral = dtGeneral.Rows[b];

                        if (drGeneral["NumPosicion"].ToString().Trim() == PosicionModificada) { dataGridView1.Rows[b].DefaultCellStyle.BackColor = Color.Yellow; }

                        dataGridView1.Rows[b].Cells[0].Style.BackColor = Color.Bisque;
                        dataGridView1.Rows[b].Cells[0].Value = drGeneral["NumPosicion"].ToString().Trim();
                        dataGridView1.Rows[b].Cells[1].Value = drGeneral["NomPosicion"].ToString().Trim();
                    }

                }
                else
                {

                }
                habilitar = true;
                cn1.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("ERROR EN CARGAR DATAGRIDVIEW1 TABLA POSICIONES\n" + ex.Message);
            }
            finally
            {
            }
        }

        private void btnRefrescar_Click(object sender, EventArgs e)
        {
            habilitar = false;
            btnGUARDAR.Enabled = false;
            PosicionModificada = "";
            RellenarGridGeneral();
        }

        private void dataGridView1_RowEnter(object sender, DataGridViewCellEventArgs e)
        {
            if (habilitar == true)
            {
                filaselec = e.RowIndex;
                txtNumPosicion.Text = dataGridView1.Rows[filaselec].Cells[0].Value.ToString();
                txtNomPosicion.Text = dataGridView1.Rows[filaselec].Cells[1].Value.ToString();

                txtNomPosicion.Enabled = false;
                btnGUARDAR.Enabled = false;
            }
        }

        private void btnGUARDAR_Click(object sender, EventArgs e)
        {
            string StringUpdate;

            string Posicion_guardada;

            string TextoPosicion;
            string TextoComparado;
            int EnteroPosicion;
            TextoPosicion = txtNomPosicion.Text.Substring(0, 8);
            EnteroPosicion = int.Parse(txtNumPosicion.Text);
            if (EnteroPosicion < 10)
            {
                TextoComparado = "POS 0" + EnteroPosicion.ToString() + ". ";
            }
            else
            {
                TextoComparado = "POS " + EnteroPosicion.ToString() + ". ";
            }

            if (TextoPosicion == TextoComparado)
            {
                StringUpdate = "UPDATE Posiciones SET "
                    + "FechaHora = getdate(),"
                    + "NomPosicion = '" + txtNomPosicion.Text.Trim() + "'"
                    + " WHERE NumPosicion = " + txtNumPosicion.Text.Trim();

                Posicion_guardada = txtNumPosicion.Text.Trim();

                cn2 = new OleDbConnection(Program.CadenaConexion);

                try
                {
                    cn2.Open();
                    Comando2 = new System.Data.OleDb.OleDbCommand(StringUpdate);
                    Comando2.Connection = cn2;
                    Comando2.ExecuteNonQuery();
                    cn2.Close();

                    txtNomPosicion.Enabled = false;

                    dataGridView1.Rows.Clear();
                    habilitar = false;
                    PosicionModificada = Posicion_guardada;
                    RellenarGridGeneral();

                }
                catch (Exception ex)
                {
                    MessageBox.Show("ERROR SQL AL ACTUALIZAR TABLA POSICIONES " + ex.Message);
                }
                finally
                {
                }
            }
            else
            {
                MessageBox.Show("Sintaxis debe de ser 'POS XX. NOMBRE");
            }
        }

        private void btnEditar_Click(object sender, EventArgs e)
        {
            if (txtNomPosicion.Enabled == true)
            {
                txtNomPosicion.Enabled = false;
                btnGUARDAR.Enabled = false;
            }
            else
            {
                txtNomPosicion.Enabled = true;
                btnGUARDAR.Enabled = true;
            }
        }

        private void Form_Posiciones_Load(object sender, EventArgs e)
        {
            habilitar = false;
            btnGUARDAR.Enabled = false;
            PosicionModificada = "";
            RellenarGridGeneral();
        }
    }
}
