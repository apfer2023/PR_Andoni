﻿namespace Proyecto
{
    partial class Form_Programa
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label4 = new System.Windows.Forms.Label();
            this.txtNumPrograma = new System.Windows.Forms.NumericUpDown();
            this.btnBUSCAR = new System.Windows.Forms.Button();
            this.btnACTUALIZAR = new System.Windows.Forms.Button();
            this.btnBORRAR = new System.Windows.Forms.Button();
            this.txtNomPrograma = new System.Windows.Forms.TextBox();
            this.btnEditar = new System.Windows.Forms.Button();
            this.btnCREAR = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.lblPosOrigen = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.txtNumPrograma)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(396, 597);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(151, 13);
            this.label4.TabIndex = 371;
            this.label4.Text = "Sintaxis: PRO XX. NNNNNNN";
            // 
            // txtNumPrograma
            // 
            this.txtNumPrograma.Location = new System.Drawing.Point(232, 617);
            this.txtNumPrograma.Maximum = new decimal(new int[] {
            30,
            0,
            0,
            0});
            this.txtNumPrograma.Name = "txtNumPrograma";
            this.txtNumPrograma.ReadOnly = true;
            this.txtNumPrograma.Size = new System.Drawing.Size(56, 20);
            this.txtNumPrograma.TabIndex = 370;
            this.txtNumPrograma.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // btnBUSCAR
            // 
            this.btnBUSCAR.Location = new System.Drawing.Point(181, 105);
            this.btnBUSCAR.Name = "btnBUSCAR";
            this.btnBUSCAR.Size = new System.Drawing.Size(207, 25);
            this.btnBUSCAR.TabIndex = 365;
            this.btnBUSCAR.Text = "BUSCAR";
            this.btnBUSCAR.UseVisualStyleBackColor = true;
            this.btnBUSCAR.Click += new System.EventHandler(this.btnBUSCAR_Click);
            // 
            // btnACTUALIZAR
            // 
            this.btnACTUALIZAR.BackColor = System.Drawing.Color.Yellow;
            this.btnACTUALIZAR.Location = new System.Drawing.Point(203, 659);
            this.btnACTUALIZAR.Name = "btnACTUALIZAR";
            this.btnACTUALIZAR.Size = new System.Drawing.Size(96, 35);
            this.btnACTUALIZAR.TabIndex = 364;
            this.btnACTUALIZAR.Text = "ACTUALIZAR";
            this.btnACTUALIZAR.UseVisualStyleBackColor = false;
            this.btnACTUALIZAR.Click += new System.EventHandler(this.btnACTUALIZAR_Click);
            // 
            // btnBORRAR
            // 
            this.btnBORRAR.Location = new System.Drawing.Point(313, 700);
            this.btnBORRAR.Name = "btnBORRAR";
            this.btnBORRAR.Size = new System.Drawing.Size(100, 30);
            this.btnBORRAR.TabIndex = 363;
            this.btnBORRAR.Text = "BORRAR";
            this.btnBORRAR.UseVisualStyleBackColor = true;
            this.btnBORRAR.Click += new System.EventHandler(this.btnBORRAR_Click);
            // 
            // txtNomPrograma
            // 
            this.txtNomPrograma.Location = new System.Drawing.Point(298, 617);
            this.txtNomPrograma.MaxLength = 29;
            this.txtNomPrograma.Name = "txtNomPrograma";
            this.txtNomPrograma.Size = new System.Drawing.Size(250, 20);
            this.txtNomPrograma.TabIndex = 362;
            this.txtNomPrograma.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // btnEditar
            // 
            this.btnEditar.Location = new System.Drawing.Point(419, 700);
            this.btnEditar.Name = "btnEditar";
            this.btnEditar.Size = new System.Drawing.Size(100, 30);
            this.btnEditar.TabIndex = 361;
            this.btnEditar.Text = "EDITAR";
            this.btnEditar.UseVisualStyleBackColor = true;
            this.btnEditar.Click += new System.EventHandler(this.btnEditar_Click);
            // 
            // btnCREAR
            // 
            this.btnCREAR.Location = new System.Drawing.Point(203, 700);
            this.btnCREAR.Name = "btnCREAR";
            this.btnCREAR.Size = new System.Drawing.Size(100, 30);
            this.btnCREAR.TabIndex = 360;
            this.btnCREAR.Text = "CREAR";
            this.btnCREAR.UseVisualStyleBackColor = true;
            this.btnCREAR.Click += new System.EventHandler(this.btnCREAR_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(297, 597);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(92, 13);
            this.label1.TabIndex = 359;
            this.label1.Text = "Nombre Programa";
            // 
            // lblPosOrigen
            // 
            this.lblPosOrigen.AutoSize = true;
            this.lblPosOrigen.Location = new System.Drawing.Point(243, 597);
            this.lblPosOrigen.Name = "lblPosOrigen";
            this.lblPosOrigen.Size = new System.Drawing.Size(29, 13);
            this.lblPosOrigen.TabIndex = 358;
            this.lblPosOrigen.Text = "Num";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(221, 84);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(131, 13);
            this.label12.TabIndex = 357;
            this.label12.Text = "TABLA DE PROGRAMAS";
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(180, 140);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.Size = new System.Drawing.Size(440, 436);
            this.dataGridView1.TabIndex = 356;
            this.dataGridView1.RowEnter += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_RowEnter);
            // 
            // Form_Programa
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1884, 961);
            this.ControlBox = false;
            this.Controls.Add(this.label4);
            this.Controls.Add(this.txtNumPrograma);
            this.Controls.Add(this.btnBUSCAR);
            this.Controls.Add(this.btnACTUALIZAR);
            this.Controls.Add(this.btnBORRAR);
            this.Controls.Add(this.txtNomPrograma);
            this.Controls.Add(this.btnEditar);
            this.Controls.Add(this.btnCREAR);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lblPosOrigen);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.dataGridView1);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Form_Programa";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "PROGRAMAS";
            this.Load += new System.EventHandler(this.Form_Programa_Load);
            ((System.ComponentModel.ISupportInitialize)(this.txtNumPrograma)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.NumericUpDown txtNumPrograma;
        private System.Windows.Forms.Button btnBUSCAR;
        public System.Windows.Forms.Button btnACTUALIZAR;
        private System.Windows.Forms.Button btnBORRAR;
        private System.Windows.Forms.TextBox txtNomPrograma;
        private System.Windows.Forms.Button btnEditar;
        private System.Windows.Forms.Button btnCREAR;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblPosOrigen;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.DataGridView dataGridView1;
    }
}