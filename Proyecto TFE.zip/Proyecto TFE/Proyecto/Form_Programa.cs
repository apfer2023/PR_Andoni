﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;

namespace Proyecto
{
    public partial class Form_Programa : Form
    {

        public OleDbConnection cn1;
        public OleDbConnection cn3;
        public OleDbConnection cn4;
        public OleDbConnection cn5;
        public OleDbConnection cn6;
        public OleDbConnection cn7;
        public OleDbConnection cn8;

        public System.Data.OleDb.OleDbCommand Comando4;
        public System.Data.OleDb.OleDbCommand Comando5;
        public System.Data.OleDb.OleDbCommand Comando6;
        public System.Data.OleDb.OleDbCommand Comando7;
        public System.Data.OleDb.OleDbCommand Comando8;

        public System.Data.OleDb.OleDbDataReader lector;
        public System.Data.OleDb.OleDbDataReader lector7;
        public System.Data.OleDb.OleDbDataReader lector8;

        public System.Data.OleDb.OleDbTransaction Trans5;

        public string SelectComboBox;
        public DataSet dsCombobox;
        public DataTable dtCombobox;
        public DataRow drCombobox;
        public OleDbDataAdapter caCombobox;

        public string MiSelectPiezas;
        public DataSet dsPiezas;
        public DataTable dtPiezas;
        public DataRow drPiezas;
        public OleDbDataAdapter caPiezas;
        //public OdbcDataAdapter caPiezas;

        public bool habilitar;

        public bool habilitar_guardar;
        public string ProgramaModificado;
        public string ProgramaAuxiliar;

        public Form_Programa()
        {
            InitializeComponent();
            habilitar = false;
            txtNomPrograma.Text = "";
            ProgramaModificado = "";
            btnBORRAR.Enabled = false;
            btnCREAR.Enabled = false;
            btnACTUALIZAR.Visible = false;

        }


        private void RellenarGrid3(string NumPrograma, string NomPrograma)
        {
            int b = 0;
            cn3 = new OleDbConnection(Program.CadenaConexion);

            try
            {
                cn3.Open();
                dataGridView1.Rows.Clear();

                txtNomPrograma.Enabled = false;

                if (NomPrograma.Length >= 2)
                {
                    MiSelectPiezas = "SELECT * FROM GeneralProgramas WHERE NomPrograma like '%" + NomPrograma + "%' ORDER BY NumPrograma ASC";
                }
                else
                {
                    if (NumPrograma.Length > 0)
                    {
                        MiSelectPiezas = "SELECT * FROM GeneralProgramas WHERE NumPrograma like '%" + NumPrograma + "%' ORDER BY NumPrograma ASC";
                    }
                    else
                    {
                        MiSelectPiezas = "SELECT * FROM GeneralProgramas ORDER BY NumPrograma ASC ";
                    }
                }

                dsPiezas = new System.Data.DataSet();
                dtPiezas = new System.Data.DataTable();
                caPiezas = new OleDbDataAdapter(MiSelectPiezas, cn3);
                caPiezas.Fill(dsPiezas, "Piezas");
                dataGridView1.AutoGenerateColumns = false;
                dataGridView1.ColumnCount = 3;
                dtPiezas = dsPiezas.Tables[0];

                dataGridView1.Columns[0].Name = "FECHAHORA";
                dataGridView1.Columns[1].Name = "NUM";
                dataGridView1.Columns[2].Name = "NOMBRE PROGRAMA";

                dataGridView1.Columns["FECHAHORA"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
                dataGridView1.Columns["NUM"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
                dataGridView1.Columns["NOMBRE PROGRAMA"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;

                dataGridView1.Columns["FECHAHORA"].Width = 120;
                dataGridView1.Columns["NUM"].Width = 60;
                dataGridView1.Columns["NOMBRE PROGRAMA"].Width = 216;

                dataGridView1.Columns["FECHAHORA"].SortMode = DataGridViewColumnSortMode.NotSortable;
                dataGridView1.Columns["NUM"].SortMode = DataGridViewColumnSortMode.NotSortable;
                dataGridView1.Columns["NOMBRE PROGRAMA"].SortMode = DataGridViewColumnSortMode.NotSortable;


                if (dtPiezas.Rows.Count > 0)
                {
                    dataGridView1.Rows.Add(dtPiezas.Rows.Count);

                }

                if (dtPiezas.Rows.Count > 0)
                {

                    for (b = 0; b < dtPiezas.Rows.Count; b++)
                    {
                        drPiezas = dtPiezas.Rows[b];

                        if (drPiezas["NomPrograma"].ToString().Trim() == ProgramaModificado) { dataGridView1.Rows[b].DefaultCellStyle.BackColor = Color.Yellow; }

                        btnEditar.Enabled = true;

                        dataGridView1.Rows[b].Cells[0].Value = drPiezas["FechaHora"].ToString().Trim();
                        dataGridView1.Rows[b].Cells[1].Value = drPiezas["NumPrograma"].ToString().Trim();
                        dataGridView1.Rows[b].Cells[2].Value = drPiezas["NomPrograma"].ToString().Trim();

                    }

                }
                habilitar = true;


                cn3.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("ERROR EN CARGAR DATAGRIDVIEW1 GENERALPROGRAMAS \n" + " " + MiSelectPiezas + " " + ex.Message);
            }
            finally
            {
            }

        }

        private void btnRefrescar_Click(object sender, EventArgs e)
        {
            habilitar = false;
            btnACTUALIZAR.Visible = false;
            RellenarGrid3("", "");
        }

        private void btnEditar_Click(object sender, EventArgs e)
        {
            if (txtNumPrograma.Enabled == true)
            {
                txtNumPrograma.Enabled = false;
                txtNomPrograma.Enabled = false;
                btnBORRAR.Enabled = false;
                btnCREAR.Enabled = false;
                btnACTUALIZAR.Visible = false;
            }

            else
            {
                txtNumPrograma.Enabled = true;
                txtNomPrograma.Enabled = true;
                btnBORRAR.Enabled = true;
                btnCREAR.Enabled = true;
            }

        }

        private void btnBORRAR_Click(object sender, EventArgs e)
        {
            string StringDelete1;
            string StringDelete2;

            cn5 = new OleDbConnection(Program.CadenaConexion);

            StringDelete1 = "DELETE FROM GeneralProgramas WHERE NumPrograma = " + txtNumPrograma.Text;
            StringDelete2 = "DELETE FROM DetalleProgramas WHERE NumPrograma = " + txtNumPrograma.Text;

            cn5.Open();
            Comando5 = new System.Data.OleDb.OleDbCommand();
            Trans5 = cn5.BeginTransaction();
            Comando5.Connection = cn5;
            Comando5.Transaction = Trans5;

            Comando5.CommandText = StringDelete1;
            Comando5.ExecuteNonQuery();
            Comando5.CommandText = StringDelete2;
            Comando5.ExecuteNonQuery();
            Trans5.Commit();
            cn5.Close();

            btnBORRAR.Enabled = false;
            btnCREAR.Enabled = false;
            btnACTUALIZAR.Visible = false;

            dataGridView1.Rows.Clear();
            habilitar = false;
            ProgramaModificado = "";
            RellenarGrid3("", "");

        }

        private void btnCREAR_Click(object sender, EventArgs e)
        {
            string StringUpdate;
            String StringSelect;

            string Programa_guardado;

            bool NumPrograma_ok;
            bool NomPrograma_ok;

            string TextoProgramaCod01;
            string TextoProgramaCod02;
            string TextoProgramaCod03;

            int EnteroPrograma;

            TextoProgramaCod01 = txtNomPrograma.Text.Substring(0, 4);
            TextoProgramaCod02 = txtNomPrograma.Text.Substring(4, 2);
            TextoProgramaCod03 = txtNomPrograma.Text.Substring(6, 1);

            try
            {

                EnteroPrograma = int.Parse(TextoProgramaCod02);


                if ((EnteroPrograma > 0) & (EnteroPrograma < 30)) { NumPrograma_ok = true; } else { NumPrograma_ok = false; };
                if ((txtNomPrograma.Text.Length > 10) & (TextoProgramaCod01 == "PRO ") & (TextoProgramaCod03 == ".")) { NomPrograma_ok = true; } else { NomPrograma_ok = false; };

                if (NumPrograma_ok && NomPrograma_ok && txtNomPrograma.Enabled)
                {
                    habilitar_guardar = true;
                    Programa_guardado = txtNomPrograma.Text;
                }
                else
                {
                    habilitar_guardar = false;
                    Programa_guardado = "";
                }

                cn7 = new OleDbConnection(Program.CadenaConexion);
                StringSelect = "SELECT * FROM GeneralProgramas WHERE NumPrograma = " + EnteroPrograma.ToString().Trim();
                cn7.Open();
                Comando7 = new System.Data.OleDb.OleDbCommand(StringSelect);
                Comando7.Connection = cn7;
                lector7 = Comando7.ExecuteReader();

                if (lector7.HasRows)
                {
                    btnACTUALIZAR.Visible = true;
                    habilitar_guardar = false;
                    btnCREAR.Enabled = false;
                    StringUpdate = "UPDATE GeneralProgramas SET "
                    + "FechaHora = getdate(),"
                    + "NumPrograma = " + EnteroPrograma.ToString().Trim() + ","
                    + "NomPrograma = '" + txtNomPrograma.Text.Trim() + "'"
                    + " WHERE NumPrograma = '" + EnteroPrograma.ToString().Trim() + "'";
                }
                else
                {
                    StringUpdate = "INSERT INTO GeneralProgramas (FechaHora,NumPrograma,NomPrograma) VALUES ("
                    + "getdate(),"
                    + "" + EnteroPrograma.ToString().Trim() + ","
                    + "'" + txtNomPrograma.Text.Trim() + "')";
                }

                lector7.Close();
                cn7.Close();

                cn6 = new OleDbConnection(Program.CadenaConexion);

                //try
                //{
                if (habilitar_guardar)
                {
                    cn6.Open();
                    Comando6 = new System.Data.OleDb.OleDbCommand(StringUpdate);
                    Comando6.Connection = cn6;
                    Comando6.ExecuteNonQuery();
                    cn6.Close();

                    txtNumPrograma.Enabled = false;
                    txtNomPrograma.Enabled = false;
                    btnBORRAR.Enabled = false;
                    btnCREAR.Enabled = false;
                    btnACTUALIZAR.Visible = false;

                    dataGridView1.Rows.Clear();
                    habilitar = false;
                    ProgramaModificado = Programa_guardado;
                    RellenarGrid3("", "");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("ERROR SQL AL PROGRAMASGENERAL " + ex.Message);
            }
            finally
            {
            }
        }

        private void btnBUSCAR_Click(object sender, EventArgs e)
        {
            string NumProgramaBuscado;
            string NomProgramaBuscado;
            NumProgramaBuscado = "";
            NomProgramaBuscado = "";
            dataGridView1.Rows.Clear();
            habilitar = false;
            ProgramaModificado = "";
            RellenarGrid3(NumProgramaBuscado, NomProgramaBuscado);
        }

        private void btnACTUALIZAR_Click(object sender, EventArgs e)
        {
            string StringUpdate;
            String StringSelect;

            string Programa_guardado;

            bool NumPrograma_ok;
            bool NomPrograma_ok;

            string TextoProgramaCod01;
            string TextoProgramaCod02;
            string TextoProgramaCod03;

            int EnteroPrograma;

            TextoProgramaCod01 = txtNomPrograma.Text.Substring(0, 4);
            TextoProgramaCod02 = txtNomPrograma.Text.Substring(4, 2);
            TextoProgramaCod03 = txtNomPrograma.Text.Substring(6, 1);

            try
            {

                EnteroPrograma = int.Parse(TextoProgramaCod02);

                if ((EnteroPrograma > 0) & (EnteroPrograma < 30)) { NumPrograma_ok = true; } else { NumPrograma_ok = false; };
                if ((txtNomPrograma.Text.Length > 10) & (TextoProgramaCod01 == "PRO ") & (TextoProgramaCod03 == ".")) { NomPrograma_ok = true; } else { NomPrograma_ok = false; };

                if (NumPrograma_ok && NomPrograma_ok && txtNomPrograma.Enabled)
                {
                    habilitar_guardar = true;
                    Programa_guardado = txtNomPrograma.Text;
                }
                else
                {
                    habilitar_guardar = false;
                    Programa_guardado = "";
                }

                cn7 = new OleDbConnection(Program.CadenaConexion);
                StringSelect = "SELECT * FROM GeneralProgramas WHERE NumPrograma = " + EnteroPrograma.ToString().Trim();
                cn7.Open();
                Comando7 = new System.Data.OleDb.OleDbCommand(StringSelect);
                Comando7.Connection = cn7;
                lector7 = Comando7.ExecuteReader();

                if (lector7.HasRows)
                {
                    StringUpdate = "UPDATE GeneralProgramas SET "
                    + "FechaHora = getdate(),"
                    + "NumPrograma = " + EnteroPrograma.ToString().Trim() + ","
                    + "NomPrograma = '" + txtNomPrograma.Text.Trim() + "'"
                    + " WHERE NumPrograma = '" + EnteroPrograma.ToString().Trim() + "'";
                }
                else
                {
                    StringUpdate = "INSERT INTO GeneralProgramas (FechaHora,NumPrograma,NomPrograma) VALUES ("
                    + "getdate(),"
                    + "" + EnteroPrograma.ToString().Trim() + ","
                    + "'" + txtNomPrograma.Text.Trim() + "')";
                }

                lector7.Close();
                cn7.Close();

                cn6 = new OleDbConnection(Program.CadenaConexion);

                //try
                //{
                if (habilitar_guardar)
                {
                    cn6.Open();
                    Comando6 = new System.Data.OleDb.OleDbCommand(StringUpdate);
                    Comando6.Connection = cn6;
                    Comando6.ExecuteNonQuery();
                    cn6.Close();

                    txtNumPrograma.Enabled = false;
                    txtNomPrograma.Enabled = false;
                    btnBORRAR.Enabled = false;
                    btnCREAR.Enabled = false;
                    btnACTUALIZAR.Visible = false;

                    dataGridView1.Rows.Clear();
                    habilitar = false;
                    ProgramaModificado = Programa_guardado;
                    RellenarGrid3("", "");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("ERROR SQL AL ACEPTAR DESCARGA " + ex.Message);
            }
            finally
            {
            }
        }

        private void dataGridView1_RowEnter(object sender, DataGridViewCellEventArgs e)
        {
            int filaselec;

            if (habilitar == true)
            {
                filaselec = e.RowIndex;

                txtNumPrograma.Text = dataGridView1.Rows[filaselec].Cells[1].Value.ToString();
                txtNomPrograma.Text = dataGridView1.Rows[filaselec].Cells[2].Value.ToString();

                txtNumPrograma.Enabled = false;
                txtNomPrograma.Enabled = false;
                btnBORRAR.Enabled = false;
                btnCREAR.Enabled = false;
                btnACTUALIZAR.Visible = false;
            }
        }

        private void Form_Programa_Load(object sender, EventArgs e)
        {
            string NumProgramaBuscado;
            string NomProgramaBuscado;
            NumProgramaBuscado = "";
            NomProgramaBuscado = "";
            dataGridView1.Rows.Clear();
            habilitar = false;
            ProgramaModificado = "";
            RellenarGrid3(NumProgramaBuscado, NomProgramaBuscado);
        }
    }
}
