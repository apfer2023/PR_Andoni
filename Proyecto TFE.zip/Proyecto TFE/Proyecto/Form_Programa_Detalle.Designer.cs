﻿namespace Proyecto
{
    partial class Form_Programa_Detalle
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.btnBUSCAR = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.label1 = new System.Windows.Forms.Label();
            this.comboBoxPosiciones = new System.Windows.Forms.ComboBox();
            this.txtNumProgramaSeleccionado = new System.Windows.Forms.TextBox();
            this.txtNomProgramaSeleccionado = new System.Windows.Forms.TextBox();
            this.lblNomProgSelec = new System.Windows.Forms.Label();
            this.lblOrden = new System.Windows.Forms.Label();
            this.txtOrden = new System.Windows.Forms.TextBox();
            this.btnEliminar = new System.Windows.Forms.Button();
            this.btnModificar = new System.Windows.Forms.Button();
            this.btnInsertar = new System.Windows.Forms.Button();
            this.btnAgregar = new System.Windows.Forms.Button();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.txtTiempoMax = new System.Windows.Forms.NumericUpDown();
            this.txtTiempoSet = new System.Windows.Forms.NumericUpDown();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtTiempoMax)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtTiempoSet)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView2
            // 
            this.dataGridView2.AllowUserToAddRows = false;
            this.dataGridView2.AllowUserToDeleteRows = false;
            this.dataGridView2.AllowUserToResizeColumns = false;
            this.dataGridView2.AllowUserToResizeRows = false;
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Location = new System.Drawing.Point(538, 122);
            this.dataGridView2.MultiSelect = false;
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.ReadOnly = true;
            this.dataGridView2.Size = new System.Drawing.Size(465, 436);
            this.dataGridView2.TabIndex = 363;
            this.dataGridView2.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView2_CellClick);
            // 
            // btnBUSCAR
            // 
            this.btnBUSCAR.Location = new System.Drawing.Point(49, 87);
            this.btnBUSCAR.Name = "btnBUSCAR";
            this.btnBUSCAR.Size = new System.Drawing.Size(207, 25);
            this.btnBUSCAR.TabIndex = 358;
            this.btnBUSCAR.Text = "BUSCAR";
            this.btnBUSCAR.UseVisualStyleBackColor = true;
            this.btnBUSCAR.Click += new System.EventHandler(this.btnBUSCAR_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.AllowUserToResizeColumns = false;
            this.dataGridView1.AllowUserToResizeRows = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(48, 122);
            this.dataGridView1.MultiSelect = false;
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.Size = new System.Drawing.Size(440, 436);
            this.dataGridView1.TabIndex = 356;
            this.dataGridView1.RowEnter += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_RowEnter);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(1078, 200);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(58, 13);
            this.label1.TabIndex = 399;
            this.label1.Text = "Posiciones";
            // 
            // comboBoxPosiciones
            // 
            this.comboBoxPosiciones.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxPosiciones.FormattingEnabled = true;
            this.comboBoxPosiciones.Location = new System.Drawing.Point(1081, 220);
            this.comboBoxPosiciones.Name = "comboBoxPosiciones";
            this.comboBoxPosiciones.Size = new System.Drawing.Size(172, 21);
            this.comboBoxPosiciones.TabIndex = 398;
            this.comboBoxPosiciones.SelectionChangeCommitted += new System.EventHandler(this.comboBoxPosiciones_SelectionChangeCommitted);
            // 
            // txtNumProgramaSeleccionado
            // 
            this.txtNumProgramaSeleccionado.Location = new System.Drawing.Point(1034, 156);
            this.txtNumProgramaSeleccionado.Name = "txtNumProgramaSeleccionado";
            this.txtNumProgramaSeleccionado.ReadOnly = true;
            this.txtNumProgramaSeleccionado.Size = new System.Drawing.Size(23, 20);
            this.txtNumProgramaSeleccionado.TabIndex = 397;
            this.txtNumProgramaSeleccionado.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtNomProgramaSeleccionado
            // 
            this.txtNomProgramaSeleccionado.Location = new System.Drawing.Point(1064, 156);
            this.txtNomProgramaSeleccionado.Name = "txtNomProgramaSeleccionado";
            this.txtNomProgramaSeleccionado.ReadOnly = true;
            this.txtNomProgramaSeleccionado.Size = new System.Drawing.Size(189, 20);
            this.txtNomProgramaSeleccionado.TabIndex = 396;
            this.txtNomProgramaSeleccionado.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lblNomProgSelec
            // 
            this.lblNomProgSelec.AutoSize = true;
            this.lblNomProgSelec.Location = new System.Drawing.Point(1066, 135);
            this.lblNomProgSelec.Name = "lblNomProgSelec";
            this.lblNomProgSelec.Size = new System.Drawing.Size(92, 13);
            this.lblNomProgSelec.TabIndex = 395;
            this.lblNomProgSelec.Text = "Nombre Programa";
            // 
            // lblOrden
            // 
            this.lblOrden.AutoSize = true;
            this.lblOrden.Location = new System.Drawing.Point(1035, 200);
            this.lblOrden.Name = "lblOrden";
            this.lblOrden.Size = new System.Drawing.Size(36, 13);
            this.lblOrden.TabIndex = 394;
            this.lblOrden.Text = "Orden";
            // 
            // txtOrden
            // 
            this.txtOrden.Location = new System.Drawing.Point(1035, 220);
            this.txtOrden.Name = "txtOrden";
            this.txtOrden.ReadOnly = true;
            this.txtOrden.Size = new System.Drawing.Size(36, 20);
            this.txtOrden.TabIndex = 393;
            this.txtOrden.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // btnEliminar
            // 
            this.btnEliminar.Location = new System.Drawing.Point(1386, 289);
            this.btnEliminar.Name = "btnEliminar";
            this.btnEliminar.Size = new System.Drawing.Size(100, 54);
            this.btnEliminar.TabIndex = 387;
            this.btnEliminar.Text = "ELIMINAR SELECIONADO";
            this.btnEliminar.UseVisualStyleBackColor = true;
            this.btnEliminar.Click += new System.EventHandler(this.btnEliminar_Click);
            // 
            // btnModificar
            // 
            this.btnModificar.Location = new System.Drawing.Point(1268, 289);
            this.btnModificar.Name = "btnModificar";
            this.btnModificar.Size = new System.Drawing.Size(100, 54);
            this.btnModificar.TabIndex = 386;
            this.btnModificar.Text = "MODIFICAR SELECIONADO";
            this.btnModificar.UseVisualStyleBackColor = true;
            this.btnModificar.Click += new System.EventHandler(this.btnModificar_Click);
            // 
            // btnInsertar
            // 
            this.btnInsertar.Location = new System.Drawing.Point(1150, 289);
            this.btnInsertar.Name = "btnInsertar";
            this.btnInsertar.Size = new System.Drawing.Size(100, 54);
            this.btnInsertar.TabIndex = 385;
            this.btnInsertar.Text = "INSERTAR DETRAS SELECIONADO";
            this.btnInsertar.UseVisualStyleBackColor = true;
            this.btnInsertar.Click += new System.EventHandler(this.btnInsertar_Click);
            // 
            // btnAgregar
            // 
            this.btnAgregar.Location = new System.Drawing.Point(1034, 289);
            this.btnAgregar.Name = "btnAgregar";
            this.btnAgregar.Size = new System.Drawing.Size(100, 54);
            this.btnAgregar.TabIndex = 384;
            this.btnAgregar.Text = "AGREGAR AL FINAL DE LA SECUENCA";
            this.btnAgregar.UseVisualStyleBackColor = true;
            this.btnAgregar.Click += new System.EventHandler(this.btnAgregar_Click);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(1335, 205);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(62, 13);
            this.label10.TabIndex = 477;
            this.label10.Text = "TiempoMax";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(1268, 205);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(58, 13);
            this.label9.TabIndex = 476;
            this.label9.Text = "TiempoSet";
            // 
            // txtTiempoMax
            // 
            this.txtTiempoMax.Location = new System.Drawing.Point(1340, 221);
            this.txtTiempoMax.Maximum = new decimal(new int[] {
            500,
            0,
            0,
            0});
            this.txtTiempoMax.Minimum = new decimal(new int[] {
            2,
            0,
            0,
            0});
            this.txtTiempoMax.Name = "txtTiempoMax";
            this.txtTiempoMax.Size = new System.Drawing.Size(56, 20);
            this.txtTiempoMax.TabIndex = 475;
            this.txtTiempoMax.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtTiempoMax.Value = new decimal(new int[] {
            200,
            0,
            0,
            0});
            // 
            // txtTiempoSet
            // 
            this.txtTiempoSet.Location = new System.Drawing.Point(1271, 221);
            this.txtTiempoSet.Maximum = new decimal(new int[] {
            500,
            0,
            0,
            0});
            this.txtTiempoSet.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.txtTiempoSet.Name = "txtTiempoSet";
            this.txtTiempoSet.Size = new System.Drawing.Size(56, 20);
            this.txtTiempoSet.TabIndex = 474;
            this.txtTiempoSet.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtTiempoSet.Value = new decimal(new int[] {
            120,
            0,
            0,
            0});
            this.txtTiempoSet.ValueChanged += new System.EventHandler(this.txtTiempoSet_ValueChanged);
            // 
            // Form_Programa_Detalle
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1884, 961);
            this.ControlBox = false;
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.txtTiempoMax);
            this.Controls.Add(this.txtTiempoSet);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.comboBoxPosiciones);
            this.Controls.Add(this.txtNumProgramaSeleccionado);
            this.Controls.Add(this.txtNomProgramaSeleccionado);
            this.Controls.Add(this.lblNomProgSelec);
            this.Controls.Add(this.lblOrden);
            this.Controls.Add(this.txtOrden);
            this.Controls.Add(this.btnEliminar);
            this.Controls.Add(this.btnModificar);
            this.Controls.Add(this.btnInsertar);
            this.Controls.Add(this.btnAgregar);
            this.Controls.Add(this.dataGridView2);
            this.Controls.Add(this.btnBUSCAR);
            this.Controls.Add(this.dataGridView1);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Form_Programa_Detalle";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "PROGRAMA DETALLE";
            this.Load += new System.EventHandler(this.Form_Programa_Detalle_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtTiempoMax)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtTiempoSet)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.Button btnBUSCAR;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox comboBoxPosiciones;
        private System.Windows.Forms.TextBox txtNumProgramaSeleccionado;
        private System.Windows.Forms.TextBox txtNomProgramaSeleccionado;
        private System.Windows.Forms.Label lblNomProgSelec;
        private System.Windows.Forms.Label lblOrden;
        private System.Windows.Forms.TextBox txtOrden;
        private System.Windows.Forms.Button btnEliminar;
        private System.Windows.Forms.Button btnModificar;
        private System.Windows.Forms.Button btnInsertar;
        private System.Windows.Forms.Button btnAgregar;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.NumericUpDown txtTiempoMax;
        private System.Windows.Forms.NumericUpDown txtTiempoSet;
    }
}