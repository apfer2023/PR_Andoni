﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;

namespace Proyecto
{
    public partial class Form_Programa_Detalle : Form
    {

        public OleDbConnection cn1;
        public OleDbConnection cn3;
        public OleDbConnection cn4;
        public OleDbConnection cn5;
        public OleDbConnection cn6;
        public OleDbConnection cn7;
        public OleDbConnection cn8;
        public OleDbConnection cn10;
        public OleDbConnection cn11;
        public OleDbConnection cn12;

        public System.Data.OleDb.OleDbCommand Comando4;
        public System.Data.OleDb.OleDbCommand Comando5;
        public System.Data.OleDb.OleDbCommand Comando6;
        public System.Data.OleDb.OleDbCommand Comando7;
        public System.Data.OleDb.OleDbCommand Comando8;
        public System.Data.OleDb.OleDbCommand Comando10;
        public System.Data.OleDb.OleDbCommand Comando11;
        public System.Data.OleDb.OleDbCommand Comando12;

        public System.Data.OleDb.OleDbDataReader lector;
        public System.Data.OleDb.OleDbDataReader lector7;
        public System.Data.OleDb.OleDbDataReader lector8;
        public System.Data.OleDb.OleDbDataReader lector10;
        public System.Data.OleDb.OleDbDataReader lector11;
        public System.Data.OleDb.OleDbDataReader lector12;

        public System.Data.OleDb.OleDbTransaction Trans10;

        public string SelectComboBox;
        public DataSet dsCombobox;
        public DataTable dtCombobox;
        public DataRow drCombobox;
        public OleDbDataAdapter caCombobox;

        public string MiSelectPiezas;
        public DataSet dsPiezas;
        public DataTable dtPiezas;
        public DataRow drPiezas;
        public OleDbDataAdapter caPiezas;
        //public OdbcDataAdapter caPiezas;

        public string MiSelectPosiciones;
        public DataSet dsPosiciones;
        public DataTable dtPosiciones;
        public DataRow drPosiciones;
        public OleDbDataAdapter caPosiciones;

        public bool habilitar;
        public bool habilitar2;

        public bool habilitar_guardar;
        public string ProgramaModificado;
        public string ProgramaAuxiliar;

        public string PosicionSelecionadaCB;

        public Form_Programa_Detalle()
        {
            InitializeComponent();
            habilitar = false;
            habilitar2 = false;
            ProgramaModificado = "";
            PosicionSelecionadaCB = "";




            string StringSelect;
            string PosicionLeida;

            cn12 = new OleDbConnection(Program.CadenaConexion);
            cn12.Open();

            StringSelect = "SELECT NomPosicion FROM Posiciones ORDER BY NumPosicion ASC";

            Comando12 = new System.Data.OleDb.OleDbCommand(StringSelect);
            Comando12.Connection = cn12;
            lector12 = Comando12.ExecuteReader();

            if (lector12.HasRows)
            {

                while (lector12.Read())
                {

                    PosicionLeida = lector12.GetString(0);
                    comboBoxPosiciones.Items.Add(PosicionLeida);

                }

            }

            lector12.Close();
            cn12.Close();

        }


        private void RellenarGrid1(string NumPrograma, string NomPrograma)
        {
            int b = 0;
            cn3 = new OleDbConnection(Program.CadenaConexion);

            try
            {
                cn3.Open();
                dataGridView1.Rows.Clear();

                if (NomPrograma.Length >= 2)
                {
                    MiSelectPiezas = "SELECT * FROM GeneralProgramas WHERE NomPrograma like '%" + NomPrograma + "%' ORDER BY NumPrograma ASC";
                }
                else
                {
                    if (NumPrograma.Length > 0)
                    {
                        MiSelectPiezas = "SELECT * FROM GeneralProgramas WHERE NumPrograma like '%" + NumPrograma + "%' ORDER BY NumPrograma ASC";
                    }
                    else
                    {
                        MiSelectPiezas = "SELECT * FROM GeneralProgramas ORDER BY NumPrograma ASC ";
                    }
                }

                dsPiezas = new System.Data.DataSet();
                dtPiezas = new System.Data.DataTable();
                caPiezas = new OleDbDataAdapter(MiSelectPiezas, cn3);
                caPiezas.Fill(dsPiezas, "Piezas");
                dataGridView1.AutoGenerateColumns = false;
                dataGridView1.ColumnCount = 3;
                dtPiezas = dsPiezas.Tables[0];

                dataGridView1.Columns[0].Name = "FECHAHORA";
                dataGridView1.Columns[1].Name = "NUM";
                dataGridView1.Columns[2].Name = "NOMBRE PROGRAMA";

                dataGridView1.Columns["FECHAHORA"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
                dataGridView1.Columns["NUM"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
                dataGridView1.Columns["NOMBRE PROGRAMA"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;

                dataGridView1.Columns["FECHAHORA"].Width = 120;
                dataGridView1.Columns["NUM"].Width = 60;
                dataGridView1.Columns["NOMBRE PROGRAMA"].Width = 216;

                dataGridView1.Columns["FECHAHORA"].SortMode = DataGridViewColumnSortMode.NotSortable;
                dataGridView1.Columns["NUM"].SortMode = DataGridViewColumnSortMode.NotSortable;
                dataGridView1.Columns["NOMBRE PROGRAMA"].SortMode = DataGridViewColumnSortMode.NotSortable;


                if (dtPiezas.Rows.Count > 0)
                {
                    dataGridView1.Rows.Add(dtPiezas.Rows.Count);

                }

                if (dtPiezas.Rows.Count > 0)
                {

                    for (b = 0; b < dtPiezas.Rows.Count; b++)
                    {
                        drPiezas = dtPiezas.Rows[b];

                        if (drPiezas["NumPrograma"].ToString().Trim() == ProgramaModificado) { dataGridView1.Rows[b].DefaultCellStyle.BackColor = Color.Yellow; }

                        dataGridView1.Rows[b].Cells[0].Value = drPiezas["FechaHora"].ToString().Trim();
                        dataGridView1.Rows[b].Cells[1].Value = drPiezas["NumPrograma"].ToString().Trim();
                        dataGridView1.Rows[b].Cells[2].Value = drPiezas["NomPrograma"].ToString().Trim();

                    }
                    habilitar = true;
                    habilitar2 = false;
                }



                cn3.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("ERROR EN CARGAR DATAGRIDVIEW1 GENERALPROGRAMAS \n" + " " + MiSelectPiezas + " " + ex.Message);
            }
            finally
            {
            }

        }


        private void RellenarGrid2(string NumPrograma, string NomPrograma)
        {
            int b = 0;
            cn1 = new OleDbConnection(Program.CadenaConexion);

            try
            {
                cn1.Open();
                dataGridView2.Rows.Clear();

                MiSelectPosiciones = "SELECT * FROM DetalleProgramas WHERE NumPrograma = " + NumPrograma + " ORDER BY Orden ASC";


                dsPosiciones = new System.Data.DataSet();
                dtPosiciones = new System.Data.DataTable();
                caPosiciones = new OleDbDataAdapter(MiSelectPosiciones, cn1);
                caPosiciones.Fill(dsPosiciones, "Posiciones");
                dataGridView2.AutoGenerateColumns = false;
                dataGridView2.ColumnCount = 4;
                dtPosiciones = dsPosiciones.Tables[0];

                dataGridView2.Columns[0].Name = "ORDEN";
                dataGridView2.Columns[1].Name = "POSICION";
                dataGridView2.Columns[2].Name = "TIEMPOSET";
                dataGridView2.Columns[3].Name = "TIEMPOMAX";

                dataGridView2.Columns["ORDEN"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
                dataGridView2.Columns["POSICION"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
                dataGridView2.Columns["TIEMPOSET"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
                dataGridView2.Columns["TIEMPOMAX"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

                dataGridView2.Columns["ORDEN"].Width = 60;
                dataGridView2.Columns["POSICION"].Width = 180;
                dataGridView2.Columns["TIEMPOSET"].Width = 90;
                dataGridView2.Columns["TIEMPOMAX"].Width = 90;

                dataGridView2.Columns["ORDEN"].SortMode = DataGridViewColumnSortMode.NotSortable;
                dataGridView2.Columns["POSICION"].SortMode = DataGridViewColumnSortMode.NotSortable;
                dataGridView2.Columns["TIEMPOSET"].SortMode = DataGridViewColumnSortMode.NotSortable;
                dataGridView2.Columns["TIEMPOMAX"].SortMode = DataGridViewColumnSortMode.NotSortable;


                if (dtPosiciones.Rows.Count > 0)
                {
                    dataGridView2.Rows.Add(dtPosiciones.Rows.Count);

                }

                if (dtPosiciones.Rows.Count > 0)
                {

                    for (b = 0; b < dtPosiciones.Rows.Count; b++)
                    {
                        drPosiciones = dtPosiciones.Rows[b];

                        //if (drPosiciones["NumPrograma"].ToString().Trim() == ProgramaModificado) { dataGridView2.Rows[b].DefaultCellStyle.BackColor = Color.Yellow; }

                        //btnEditar.Enabled = true;

                        dataGridView2.Rows[b].Cells[0].Value = drPosiciones["Orden"].ToString().Trim();
                        dataGridView2.Rows[b].Cells[1].Value = drPosiciones["NomPosicion"].ToString().Trim();
                        dataGridView2.Rows[b].Cells[2].Value = drPosiciones["TiempoSet"].ToString().Trim();
                        dataGridView2.Rows[b].Cells[3].Value = drPosiciones["TiempoMax"].ToString().Trim();
                    }
                    //habilitar2 = true;
                }


                txtNumProgramaSeleccionado.Text = NumPrograma;
                txtNomProgramaSeleccionado.Text = NomPrograma;

                cn1.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("ERROR EN CARGAR DATAGRIDVIEW2 DETALLE PROGRAMAS \n" + " " + MiSelectPosiciones + " " + ex.Message);
            }
            finally
            {
            }

        }

        private void btnBUSCAR_Click(object sender, EventArgs e)
        {
            string NumProgramaBuscado;
            string NomProgramaBuscado;
            NumProgramaBuscado = "";
            NomProgramaBuscado = "";
            dataGridView1.Rows.Clear();
            habilitar = false;
            ProgramaModificado = "";
            RellenarGrid1(NumProgramaBuscado, NomProgramaBuscado);
        }

        private void dataGridView1_RowEnter(object sender, DataGridViewCellEventArgs e)
        {
            int filaselec;
            string NumPrograma;
            string NomPrograma;

            if (habilitar == true)
            {
                filaselec = e.RowIndex;
                NumPrograma = dataGridView1.Rows[filaselec].Cells[1].Value.ToString();
                NomPrograma = dataGridView1.Rows[filaselec].Cells[2].Value.ToString();
                RellenarGrid2(NumPrograma, NomPrograma);
                habilitar2 = true;
                txtNumProgramaSeleccionado.Text = NumPrograma;
                txtNomProgramaSeleccionado.Text = NomPrograma;
                txtOrden.Text = "1";


            }

        }

        private void btnAgregar_Click(object sender, EventArgs e)
        {
            String StringSelect;
            string StringInsert;

            string NumPosicionString;
            string NumPosicionInsert;
            int NumPosicionEntero;

            int MAX_Orden = 0;

            cn10 = new OleDbConnection(Program.CadenaConexion);
            cn10.Open();

            StringSelect = "SELECT Orden FROM DetalleProgramas WHERE NumPrograma = " + txtNumProgramaSeleccionado.Text + " ORDER BY Orden DESC";

            Comando10 = new System.Data.OleDb.OleDbCommand(StringSelect);
            Comando10.Connection = cn10;
            lector10 = Comando10.ExecuteReader();

            if (lector10.HasRows)
            {
                lector10.Read();
                MAX_Orden = Convert.ToInt16(lector10["Orden"]);
            }
            else
            {
                MAX_Orden = 0;
            }

            MAX_Orden = MAX_Orden + 1;

            lector10.Close();
            cn10.Close();

            cn11 = new OleDbConnection(Program.CadenaConexion);
            cn11.Open();


            if ((PosicionSelecionadaCB.Length > 8) & (int.Parse(txtNumProgramaSeleccionado.Text) > 0) & (txtTiempoSet.Text.Length > 0) & (txtTiempoMax.Text.Length > 0))
            {

                NumPosicionString = PosicionSelecionadaCB.Substring(4, 2);
                if (NumPosicionString.Substring(0, 1) == "0")
                {
                    NumPosicionEntero = int.Parse(NumPosicionString.Substring(1, 1));
                    NumPosicionInsert = NumPosicionEntero.ToString().Trim();
                }
                else
                {
                    NumPosicionEntero = int.Parse(NumPosicionString);
                    NumPosicionInsert = NumPosicionEntero.ToString().Trim();
                }

                StringInsert = "INSERT INTO DetalleProgramas (FechaHora,NumPrograma,Orden,NumPosicion,NomPosicion,TiempoSet,TiempoMax) VALUES ("
                + "getdate(),"
                + txtNumProgramaSeleccionado.Text.Trim() + ","
                + MAX_Orden.ToString() + ","
                + NumPosicionInsert + ","
                + "'" + PosicionSelecionadaCB.Trim() + "',"
                + txtTiempoSet.Text.Trim() + ","
                + txtTiempoMax.Text.Trim() + ")";

                try
                {
                    Comando11 = new System.Data.OleDb.OleDbCommand(StringInsert);
                    Comando11.Connection = cn11;
                    Comando11.ExecuteNonQuery();
                    cn11.Close();

                    RellenarGrid2(txtNumProgramaSeleccionado.Text, txtNomProgramaSeleccionado.Text);

                    comboBoxPosiciones.SelectedIndex = -1;
                    PosicionSelecionadaCB = "";
                }
                catch (Exception ex)
                {
                    MessageBox.Show("ERROR SQL AL AGREGAR POSICION " + ex.Message);
                }
                finally
                {
                }
                habilitar2 = true;
            }
        }

        private void comboBoxPosiciones_SelectionChangeCommitted(object sender, EventArgs e)
        {
            PosicionSelecionadaCB = comboBoxPosiciones.SelectedItem.ToString();
        }

        private void btnEliminar_Click(object sender, EventArgs e)
        {
            String StringDelete;
            string StringUpdate;

            cn10 = new OleDbConnection(Program.CadenaConexion);
            cn10.Open();
            Comando10 = new System.Data.OleDb.OleDbCommand();
            Trans10 = cn10.BeginTransaction();
            Comando10.Connection = cn10;
            Comando10.Transaction = Trans10;

            StringDelete = "DELETE FROM DetalleProgramas WHERE NumPrograma = " + txtNumProgramaSeleccionado.Text + " AND Orden = " + txtOrden.Text;
            StringUpdate = "UPDATE DetalleProgramas SET Orden = Orden - 1 WHERE NumPrograma = " + txtNumProgramaSeleccionado.Text + " AND Orden > " + txtOrden.Text;

            if ((int.Parse(txtNumProgramaSeleccionado.Text) > 0) & (int.Parse(txtOrden.Text) > 0))
            {
                try
                {

                    Comando10.CommandText = StringDelete;
                    Comando10.ExecuteNonQuery();
                    Comando10.CommandText = StringUpdate;
                    Comando10.ExecuteNonQuery();
                    Trans10.Commit();
                    cn10.Close();
                    RellenarGrid2(txtNumProgramaSeleccionado.Text, txtNomProgramaSeleccionado.Text);
                    habilitar2 = true;
                }
                catch (Exception ex)
                {
                    MessageBox.Show("ERROR SQL AL ELIMINAR " + ex.Message);
                }
                finally
                {
                }
            }


        }

        private void dataGridView2_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            int filaselec;

            string NumPosicionString;

            if ((habilitar2 == true))
            {
                filaselec = e.RowIndex;
                txtOrden.Text = dataGridView2.Rows[filaselec].Cells[0].Value.ToString();
                PosicionSelecionadaCB = dataGridView2.Rows[filaselec].Cells[1].Value.ToString().Trim();

                NumPosicionString = PosicionSelecionadaCB.Substring(4, 2);
                if (NumPosicionString.Substring(0, 1) == "0")
                {
                    comboBoxPosiciones.SelectedIndex = int.Parse(NumPosicionString.Substring(1, 1)) - 1;
                }
                else
                {
                    comboBoxPosiciones.SelectedIndex = int.Parse(NumPosicionString) - 1;
                }

                txtTiempoSet.Text = dataGridView2.Rows[filaselec].Cells[2].Value.ToString();
                txtTiempoMax.Text = dataGridView2.Rows[filaselec].Cells[3].Value.ToString();

            }
        }

        private void btnModificar_Click(object sender, EventArgs e)
        {
            string StringUpdate;
            string NumPosicionString;
            int NumPosicionEntero;

            NumPosicionString = PosicionSelecionadaCB.Substring(4, 2);
            if (NumPosicionString.Substring(0, 1) == "0")
            {
                NumPosicionEntero = int.Parse(NumPosicionString.Substring(1, 1));
            }
            else
            {
                NumPosicionEntero = int.Parse(NumPosicionString);
            }


            cn10 = new OleDbConnection(Program.CadenaConexion);
            cn10.Open();
            Comando10 = new System.Data.OleDb.OleDbCommand();
            Trans10 = cn10.BeginTransaction();
            Comando10.Connection = cn10;
            Comando10.Transaction = Trans10;

            StringUpdate = "UPDATE DetalleProgramas SET "
                + " NomPosicion = '" + PosicionSelecionadaCB.Trim() + "',"
                + " NumPosicion = " + NumPosicionEntero.ToString().Trim() + ","
                + " TiempoSet = " + txtTiempoSet.Text + ","
                + " TiempoMax = " + txtTiempoMax.Text + ""
                + " WHERE NumPrograma = " + txtNumProgramaSeleccionado.Text + " AND Orden = " + txtOrden.Text;

            if ((int.Parse(txtNumProgramaSeleccionado.Text) > 0) & (int.Parse(txtOrden.Text) > 0) & (NumPosicionEntero > 0))
            {
                try
                {

                    Comando10.CommandText = StringUpdate;
                    Comando10.ExecuteNonQuery();
                    Trans10.Commit();
                    cn10.Close();
                    RellenarGrid2(txtNumProgramaSeleccionado.Text, txtNomProgramaSeleccionado.Text);
                    habilitar2 = true;
                }
                catch (Exception ex)
                {
                    MessageBox.Show("ERROR SQL MODIFICAR " + ex.Message);
                }
                finally
                {
                }
            }
        }

        private void btnInsertar_Click(object sender, EventArgs e)
        {
            string StringUpdate;
            String StringInsert;

            int NumOrden;

            string NumPosicionString;
            int NumPosicionEntero;

            NumPosicionString = PosicionSelecionadaCB.Substring(4, 2);
            if (NumPosicionString.Substring(0, 1) == "0")
            {
                NumPosicionEntero = int.Parse(NumPosicionString.Substring(1, 1));
            }
            else
            {
                NumPosicionEntero = int.Parse(NumPosicionString);
            }

            NumOrden = int.Parse(txtOrden.Text.ToString().Trim());
            NumOrden = NumOrden + 1;

            cn10 = new OleDbConnection(Program.CadenaConexion);
            cn10.Open();
            Comando10 = new System.Data.OleDb.OleDbCommand();
            Trans10 = cn10.BeginTransaction();
            Comando10.Connection = cn10;
            Comando10.Transaction = Trans10;

            StringUpdate = "UPDATE DetalleProgramas SET Orden = Orden + 1 WHERE NumPrograma = " + txtNumProgramaSeleccionado.Text + " AND Orden > " + txtOrden.Text;
            StringInsert = "INSERT INTO DetalleProgramas(FechaHora, NumPrograma, Orden, NumPosicion, NomPosicion, TiempoSet, TiempoMax) VALUES("
                       + "getdate(),"
                       + txtNumProgramaSeleccionado.Text.Trim() + ","
                       + NumOrden.ToString().Trim() + ","
                       + NumPosicionEntero.ToString().Trim() + ","
                       + "'" + PosicionSelecionadaCB.Trim() + "',"
                       + txtTiempoSet.Text.Trim() + ","
                       + txtTiempoMax.Text.Trim() + ")";

            if ((int.Parse(txtNumProgramaSeleccionado.Text) > 0) & (int.Parse(txtOrden.Text) > 0))
            {
                try
                {

                    Comando10.CommandText = StringUpdate;
                    Comando10.ExecuteNonQuery();
                    Comando10.CommandText = StringInsert;
                    Comando10.ExecuteNonQuery();
                    Trans10.Commit();
                    cn10.Close();
                    RellenarGrid2(txtNumProgramaSeleccionado.Text, txtNomProgramaSeleccionado.Text);
                    habilitar2 = true;
                }
                catch (Exception ex)
                {
                    MessageBox.Show("ERROR SQL MODIFICAR " + ex.Message);
                }
                finally
                {
                }
            }
        }

        private void Form_Programa_Detalle_Load(object sender, EventArgs e)
        {
            string NumProgramaBuscado;
            string NomProgramaBuscado;
            NumProgramaBuscado = "";
            NomProgramaBuscado = "";
            dataGridView1.Rows.Clear();
            habilitar = false;
            ProgramaModificado = "";
            RellenarGrid1(NumProgramaBuscado, NomProgramaBuscado);
        }

        private void txtTiempoSet_ValueChanged(object sender, EventArgs e)
        {
            txtTiempoMax.Minimum = txtTiempoSet.Value;
            if (txtTiempoMax.Value < txtTiempoSet.Value)
            {
                txtTiempoMax.Value = txtTiempoSet.Value;

            }
        }
    }
}
