﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Proyecto
{
    internal static class Program
    {
        public static int MaxPosiciones = 23;
        public static int MaxBastidores = 7;
        public static int MaxPasosPorPrograma = 20;
        public static int MaxNumProgramas = 6;
        public static int MaxMovimientos = 20;
        public static int MaxMovimientosCarro = 200;
        public static int MaxCarros = 3;
        public static Int32 MaxTiempoGraph = 40000;
        public static DateTime FechaOrigen = DateTime.Now;

        public static int IDMaster;
        public static Int32 TimeMaster;

        public static int[][] Desplazamiento;

        public struct ProgramaDetalle
        {
            public Int32 TiempoSet;
            public Int32 TiempoMax;
            public int NumPrograma;
            public int NumPosicion;
            public Int32 TiempoEstancia;
        }


        public struct ResultadoStruct
        {
            public int NumPrograma;
            public int NumBastidor;
            public Int32 TimeMaster;
            public Int32 TimeFinal;
            public Int32 TimeTotal;
            public DateTime FechaInicio;
            public DateTime FechaFin;

        }

        public struct PosicionStruct
        {
            public Int32 TiempoSet;
            public Int32 TiempoMax;
            public Int32 TiempoEstancia;
            public int NumPrograma;
            public Int32 TiempoInicio;
            public int ID;
            public int NumBastidor;
        }

        public struct CarroStruct
        {
            public Int32 Tiempo;
            public int NumPrograma;
            public int PosOrigen;
            public int PosDestino;
            public Int32 TiempoInicio;
            public int ID;
            public int NumBastidor;
        }

        public static ResultadoStruct[] Resultado;
        public static ProgramaDetalle[][] Proceso;
        public static ProgramaDetalle[] ProcesoEnCambio;
        public static ProgramaDetalle[] ProcesoEnCambioZero;
        public static PosicionStruct[][] Posicion;
        public static PosicionStruct[][] PosicionBase;
        public static PosicionStruct[][] PosicionZero;
        public static CarroStruct[][] Carro;
        public static CarroStruct[][] CarroBase;
        public static CarroStruct[][] CarroZero;
        public static CarroStruct[] CarroEnCambio;
        public static CarroStruct[] CarroEnCambioZero;

        public static CarroStruct[][] CarroBastidor;
        public static CarroStruct[][] CarroBastidorBase;
        public static CarroStruct[][] CarroBastidorZero;

        public struct GanttStruct
        {
            public TextBox Te;
            public ToolTip To;
        }

        public static GanttStruct[][] PTextBox;
        public static GanttStruct[][] PTextBoxZero;
        public static GanttStruct[][] CTextBox;
        public static GanttStruct[][] CTextBoxZero;

        public static string CadenaConexion = "File Name = C:\\Conexion\\Proyecto.udl";

        public static Proyecto.Form_MDI _MDI;
        public static Proyecto.Form_Desplazamientos _oDesplazamientos;
        public static Proyecto.Form_Programa _oProgramas;
        public static Proyecto.Form_Programa_Detalle _oProgramaDetalle;
        public static Proyecto.Form_Posiciones _oPosiciones;
        public static Proyecto.Form_Introducir _oIntroducir;



        [STAThread]
        static void Main()
        {

            int a = 0;
            int b = 0;
            Process[] procesos = Process.GetProcessesByName(Process.GetCurrentProcess().ProcessName);
            if (procesos.Length <= 1)
            {
                Application.EnableVisualStyles();
                Application.SetCompatibleTextRenderingDefault(false);
                //Application.Run(new Form_MDI());

                Desplazamiento = new int[MaxPosiciones][];
                for (a = 0; a < MaxPosiciones; a++)
                {
                    Desplazamiento[a] = new int[MaxPosiciones];
                }


                Proceso = new ProgramaDetalle[MaxNumProgramas][];
                //ProcesoEnCambio = new ProgramaDetalle[MaxNumProgramas][];
                ProcesoEnCambio = new ProgramaDetalle[MaxPasosPorPrograma];
                ProcesoEnCambioZero = new ProgramaDetalle[MaxPasosPorPrograma];
                for (a = 0; a < MaxNumProgramas; a++)
                {
                    Proceso[a] = new ProgramaDetalle[MaxPasosPorPrograma];
                    //ProcesoEnCambio[a] = new ProgramaDetalle[MaxPasosPorPrograma];
                }



                Resultado = new ResultadoStruct[MaxBastidores];

                Posicion = new PosicionStruct[MaxPosiciones][];
                PosicionBase = new PosicionStruct[MaxPosiciones][];
                PosicionZero = new PosicionStruct[MaxPosiciones][];
                for (a = 0; a < MaxPosiciones; a++)
                {
                    Posicion[a] = new PosicionStruct[MaxMovimientos];
                    PosicionBase[a] = new PosicionStruct[MaxMovimientos];
                    PosicionZero[a] = new PosicionStruct[MaxMovimientos];
                }

                Carro = new CarroStruct[MaxCarros][];
                CarroBase = new CarroStruct[MaxCarros][];
                CarroZero = new CarroStruct[MaxCarros][];
                CarroEnCambio = new CarroStruct[MaxMovimientosCarro];
                CarroEnCambioZero = new CarroStruct[MaxMovimientosCarro];
                for (a = 0; a < MaxCarros; a++)
                {
                    Carro[a] = new CarroStruct[MaxMovimientosCarro];
                    CarroBase[a] = new CarroStruct[MaxMovimientosCarro];
                    CarroZero[a] = new CarroStruct[MaxMovimientosCarro];
                }

                CarroBastidor = new CarroStruct[MaxBastidores][];
                CarroBastidorBase = new CarroStruct[MaxBastidores][];
                CarroBastidorZero = new CarroStruct[MaxBastidores][];
                for (a = 0; a < MaxBastidores; a++)
                {
                    CarroBastidor[a] = new CarroStruct[MaxMovimientos];
                    CarroBastidorBase[a] = new CarroStruct[MaxMovimientos];
                    CarroBastidorZero[a] = new CarroStruct[MaxMovimientos];
                }

                PTextBox = new GanttStruct[MaxPosiciones][];
                PTextBoxZero = new GanttStruct[MaxPosiciones][];
                for (a = 0; a < MaxPosiciones; a++)
                {
                    PTextBox[a] = new GanttStruct[MaxMovimientos];
                    PTextBoxZero[a] = new GanttStruct[MaxMovimientos];

                    for (b = 0; b < MaxMovimientos; b++)
                    {
                        PTextBox[a][b].Te = new TextBox();
                        PTextBox[a][b].To = new ToolTip();
                        PTextBoxZero[a][b].Te = new TextBox();
                        PTextBoxZero[a][b].To = new ToolTip();
                    }
                }

                CTextBox = new GanttStruct[MaxCarros][];
                CTextBoxZero = new GanttStruct[MaxCarros][];
                for (a = 0; a < MaxCarros; a++)
                {
                    CTextBox[a] = new GanttStruct[MaxMovimientosCarro];
                    CTextBoxZero[a] = new GanttStruct[MaxMovimientosCarro];

                    for (b = 0; b < MaxMovimientosCarro; b++)
                    {
                        CTextBox[a][b].Te = new TextBox();
                        CTextBox[a][b].To = new ToolTip();
                        CTextBoxZero[a][b].Te = new TextBox();
                        CTextBoxZero[a][b].To = new ToolTip();
                    }
                }

                IDMaster = 1;
                TimeMaster = 0;
                Application.Run(_MDI = new Form_MDI());
            }
            else
            {
                //MessageBox.Show("LA APLICACION YA SE ESTA EJECUTANDO:" + procesos.Length.ToString());
                //Application.Exit();
            }
        }
    }
}
